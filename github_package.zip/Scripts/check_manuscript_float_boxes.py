import fitz
import sys

sys.stdout.reconfigure(encoding='utf-8')

doc = fitz.open("Manuscript.pdf")

print("=== Manuscript.pdf: Detailed Table and Figure Inspection ===")
for page_num in range(len(doc)):
    page = doc[page_num]
    rect = page.rect
    text = page.get_text("text")
    blocks = page.get_text("blocks")
    
    # Check if page has figure or table captions
    for b in blocks:
        txt = b[4].strip().replace('\n', ' ')
        if txt.startswith("Table ") or txt.startswith("Figure "):
            print(f"Page {page_num+1:02d} | Caption at y=[{b[1]:.1f}, {b[3]:.1f}], x=[{b[0]:.1f}, {b[2]:.1f}]")
            print(f"   Text: {txt[:90]}")
            
    # Check images on this page
    imgs = page.get_images()
    if imgs:
        for img in imgs:
            xref = img[0]
            img_rects = page.get_image_rects(xref)
            for ir in img_rects:
                print(f"Page {page_num+1:02d} | Image (xref {xref}) at y=[{ir.y0:.1f}, {ir.y1:.1f}], x=[{ir.x0:.1f}, {ir.x1:.1f}], width={ir.width:.1f}, height={ir.height:.1f} (Page: {rect.width} x {rect.height})")

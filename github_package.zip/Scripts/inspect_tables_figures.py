import re

for fn in ['Manuscript.tex', 'Supplementary.tex']:
    with open(fn, 'r', encoding='utf-8') as f:
        content = f.read()
    print(f'=== {fn} ===')
    tables = re.findall(r'(\\begin\{(?:table|table\*)\}.*?\\end\{(?:table|table\*)\})', content, re.DOTALL)
    print(f'Found {len(tables)} tables.')
    for i, t in enumerate(tables):
        first_line = t.split('\n')[0]
        caption = re.search(r'\\caption\{([^}]+)\}', t)
        cap_txt = caption.group(1)[:70] if caption else 'No caption'
        # check width or resizebox
        has_resize = '\\resizebox' in t
        print(f'  Table {i+1}: {first_line} | Resizebox: {has_resize} | {cap_txt}')
    
    figures = re.findall(r'(\\begin\{(?:figure|figure\*)\}.*?\\end\{(?:figure|figure\*)\})', content, re.DOTALL)
    print(f'Found {len(figures)} figures.')
    for i, fg in enumerate(figures):
        first_line = fg.split('\n')[0]
        caption = re.search(r'\\caption\{([^}]+)\}', fg)
        cap_txt = caption.group(1)[:70] if caption else 'No caption'
        # find includegraphics
        incs = re.findall(r'\\includegraphics\[(.*?)\]\{(.*?)\}', fg)
        print(f'  Figure {i+1}: {first_line} | {incs} | {cap_txt}')

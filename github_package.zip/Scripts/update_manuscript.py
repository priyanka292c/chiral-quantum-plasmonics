import os

with open('Manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Keywords: 6 keywords (drop Quantum optics)
old_kw = r'\keywords{Chiral plasmonics, Non-Markovian quantum dynamics, Helical nanoparticle assemblies, Parity breaking, Dyadic Green tensor, Information backflow, Quantum optics}'
new_kw = r'\keywords{Chiral plasmonics, Non-Markovian quantum dynamics, Helical nanoparticle assemblies, Parity breaking, Dyadic Green tensor, Information backflow}'
assert old_kw in text, 'Keywords not found'
text = text.replace(old_kw, new_kw)

# 2. Abstract: 232 words, no FDTD, BEM, BLP
old_abs_start = r'\begin{abstract}'
old_abs_end = r'\end{abstract}'
idx_start = text.find(old_abs_start)
idx_end = text.find(old_abs_end) + len(old_abs_end)
assert idx_start != -1 and idx_end != -1, 'Abstract not found'

new_abstract = r'''\begin{abstract}
Coupling quantum emitters to nanophotonic environments provides a versatile route for controlling spontaneous emission, radiative lifetimes, and quantum coherence. While localized surface plasmons in noble-metal nanoparticles offer extreme Purcell enhancements, their strong spectral dispersion and dissipative nature can induce non-Markovian memory effects. Here, we investigate whether and under what symmetry conditions the structural handedness of a chiral plasmonic assembly---specifically, a helical arrangement of gold nanospheres---can govern the open-system memory effects and quantum coherence of a nearby two-level emitter. Using three-dimensional finite-difference time-domain simulations together with independent boundary-element calculations, we compute the classical electromagnetic dyadic Green tensor and circular dichroism across a visible-to-near-infrared spectral window. Coupling these fields to a Volterra integro-differential solver in the single-excitation subspace, we evaluate the emitter's spectral density, complex memory kernel, population dynamics, and the fully optimized information-backflow measure. We establish an analytical symmetry theorem based on mirror reflection and electromagnetic reciprocity, proving that for linearly polarized emitters placed on the equatorial mirror plane, structural handedness strictly preserves identical decay dynamics and rules out chiral discrimination for point electric dipoles. Helicity-selective memory backflow requires physical parity breaking, which arises via two distinct mechanisms: spatial parity breaking from asymmetric gap docking, where near-field hotspot translocation modulates the backflow measure by 88\%; and intrinsic chiral transitions possessing coupled electric and magnetic transition dipoles, which produce pronounced handedness-dependent backflow and transient population contrast. These findings reveal fundamental symmetry constraints governing chiral open quantum systems.
\end{abstract}'''

text = text[:idx_start] + new_abstract + text[idx_end:]

# 3. Merge Section 2 and Section 3 into Section 1
intro_start = text.find(r'\section{Introduction}')
geom_start = text.find(r'\section{Geometry and Physical Parameters}')
assert intro_start != -1 and geom_start != -1, 'Sections not found'

new_intro = r'''\section{Introduction}
Controlling the interaction between single quantum emitters and structured electromagnetic reservoirs is a foundational objective of modern quantum optics, nanophotonics, and quantum information science~\cite{tame2013quantum,lodahl2015interfacing,pelton2015modified}. Metallic nanoparticles and plasmonic oligomers support localized surface plasmon resonances (LSPRs) that confine electromagnetic fields to subwavelength dimensions far below the diffraction limit~\cite{schuller2010plasmonics,giannini2011plasmonic,halas2011plasmons}. This extreme field localization yields orders-of-magnitude enhancements in the photonic local density of states (LDOS), dramatically accelerating spontaneous emission via the Purcell effect~\cite{koenderink2017single,sauvan2013theory,ge2014design}. In sub-5~nm nanogaps between adjacent metallic particles, the localized mode volume shrinks to such an extent that the emitter--plasmon coupling rate $g$ can approach or exceed the plasmon damping rate $\kappa$, pushing the hybrid system into the strong coupling regime at room temperature~\cite{chikkaraddy2016single,santhosh2016vacuum,vasa2018strong}.

Under standard weak-coupling conditions, the electromagnetic reservoir possesses a broad, featureless continuum that dephases much faster than the emitter's radiative decay. In this regime, the Wigner--Weisskopf approximation holds, and the emitter population decays exponentially in time according to a memoryless (Markovian) master equation~\cite{dung2000spontaneous,waks2010cavity}. However, near highly resonant plasmonic nanostructures, the electromagnetic environment exhibits sharp spectral variations, structured Fano interferences, and localized polaritonic dispersion~\cite{prodan2003hybridization,franke2019quantization}. When the reservoir correlation time $\tau_B$ becomes comparable to or exceeds the emitter's relaxation time $\tau_R$, the Markovian approximation breaks down entirely~\cite{breuer2009measure,breuer2016colloquium,devega2017dynamics}. In this non-Markovian regime, emitted energy and quantum information can reversibly flow back from the lossy plasmonic bath into the emitter, giving rise to transient population revivals and non-exponential coherence decay~\cite{varguet2019nonmarkovian,varguet2020spectral,medina2021nonmarkovian}.

In parallel with developments in quantum plasmonics, the emergence of chiral nanophotonics has unveiled remarkable opportunities for manipulating the polarization, spin-orbit momentum, and angular momentum of light at the nanoscale~\cite{mun2020chiral,bliokh2015spin,coles2016chirality}. Nanoparticles organized into three-dimensional chiral architectures, such as helical assemblies templated by DNA origami or colloidal lithography, exhibit giant optical activity and circular dichroism (CD) in the visible and near-infrared domains~\cite{kuzyk2012dna,shen2013rolling,fan2010plasmonic,govorov2010theory,gansel2009gold}. The near-field electromagnetic chirality within the helical interstices can surpass free-space circularly polarized fields by multiple orders of magnitude~\cite{schaferling2012tailored,hentschel2012three,frank2013large}. While chiral plasmonic nanostructures have been extensively examined for chiral sensing, circular polarizers, and asymmetric enantiomer detection~\cite{zhao2012circular,urban2013plasmonic,baranov2020strong}, their interaction with open quantum systems remains largely unexplored. Specifically, whether structural chirality can impart a directional, handedness-dependent imprint onto the \emph{memory kernel} and \emph{non-Markovian dynamics} of an adjacent emitter constitutes an open and fundamental physical question~\cite{ramos2016nonmarkovian,pichler2017universal,lodahl2018chiral,zhang2023nonmarkovian}.

The interaction of two-level quantum systems with plasmonic nanoparticles has been investigated across multiple theoretical and experimental paradigms. Early macroscopic QED formulations by Dung, Kn\"oll, and Welsch~\cite{dung2000spontaneous} and cavity QED models by Waks and Sridharan~\cite{waks2010cavity} established that the spontaneous emission rate of an emitter at position $\mathbf{r}_0$ is governed by the imaginary component of the classical dyadic Green tensor $\mathrm{Im}[\mathbf{G}(\mathbf{r}_0, \mathbf{r}_0, \omega)]$. S\l{}owik et al.~\cite{slowik2013strong} and Delga et al.~\cite{delga2014quantum} demonstrated the breakdown of the Purcell formula in deep subwavelength plasmonic cavities, revealing that non-Markovian dynamics emerge when the emitter couples strongly to localized surface plasmon modes. Subsequent investigations by Varguet et al.~\cite{varguet2019nonmarkovian,varguet2020spectral} compared master equation approaches (such as pseudomode expansions and exact Green-function convolutions) for quantum emitters coupled to single metal nanoparticles, confirming that non-Markovian population revivals occur in extreme hotspots. Medina et al.~\cite{medina2021nonmarkovian} and Urbieta et al.~\cite{urbieta2018nonmarkovian} further explored information backflow in structured plasmonic environments. Concurrently, DNA-based self-assembly enabled the fabrication of helical gold nanoparticle assemblies with nanometer precision, demonstrating giant circular dichroism and near-field optical chirality~\cite{kuzyk2012dna,shen2013rolling,munkhbat2020chiral}.

Despite these advances, existing research exhibits a pronounced bifurcation: chiral plasmonics has predominantly focused on classical far-field circular dichroism and linear optical activity~\cite{fan2010plasmonic,mun2020chiral,schaferling2012tailored}, whereas non-Markovian open quantum plasmonics has been restricted to achiral, highly symmetric geometries such as single isolated spheres, planar films, or symmetric nanosphere dimers~\cite{varguet2019nonmarkovian,slowik2013strong,ge2014design}. A comprehensive comparison of representative prior studies is summarized in Table~\ref{tab:lit_comparison}. As delineated in Table~\ref{tab:lit_comparison}, the specific unresolved question is: \emph{Does the structural handedness of a chiral plasmonic assembly intrinsically govern the non-Markovian memory kernel and population dynamics of an adjacent quantum emitter, or can all observable dynamical modifications be accounted for by ordinary scalar Purcell factor shifts?}

\begin{table*}[t]
\centering
\caption{Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.}
\label{tab:lit_comparison}
\small
\begin{tabular}{p{3.2cm}p{3.0cm}p{2.8cm}p{2.8cm}p{4.2cm}}
\toprule
\textbf{Reference} & \textbf{Geometry} & \textbf{Dynamical Method} & \textbf{Observables} & \textbf{Unresolved Gap Addressed Here} \\
\midrule
Kuzyk et al.~\cite{kuzyk2012dna} & Helical Au NP assemblies on DNA origami & Classical Mie / Dipole scattering & Far-field CD and extinction & Classical only; no quantum emitter or non-Markovian dynamics. \\
Varguet et al.~\cite{varguet2019nonmarkovian,varguet2020spectral} & Single isolated Au nanosphere ($d=20$--$50$~nm) & Green-tensor Volterra equation \& pseudomodes & $P_e(t)$, spectral density $J(\omega)$ & Achiral geometry only; no interparticle coupling or handedness effects. \\
Chikkaraddy et al.~\cite{chikkaraddy2016single} & Nanoparticle-on-mirror (NPoM) gap & Jaynes--Cummings master equation & Vacuum Rabi splitting, scattering spectra & Symmetric vertical gap mode; chirality and memory kernel structure absent. \\
Ramos et al.~\cite{ramos2016nonmarkovian} & 1D chiral quantum waveguide network & Time-delayed cascaded master equation & Waveguide photon transmission, entanglement & Abstract 1D waveguide; ignores 3D lossy plasmonic Green tensors and hotspots. \\
Zhang et al.~\cite{zhang2023nonmarkovian} & Chiral plasmonic oligomer (cross/propeller) & Lindblad master equation with FDTD LDOS & Radiative decay rate, ellipticity & Focuses on linear rate equations; does not isolate handedness in exact memory kernels. \\
\textbf{This Work} & \textbf{3D Helical Au nanosphere assemblies ($N=6,9,12$)} & \textbf{FDTD/BEM Green tensor + Volterra convolution} & \textbf{$\sigma_{\mathrm{ext}}$, CD, $F_P$, $J(\omega)$, $K(t)$, $P_e(t)$, $\rho_{eg}(t)$, $\mathcal{N}_{\mathrm{BLP}}$} & \textbf{Analytical symmetry relations and identification of parity-breaking mechanisms governing non-Markovian chiral dynamics.} \\
\bottomrule
\end{tabular}
\end{table*}

In this paper, we formulate an integrated computational framework combining macroscopic quantum electrodynamics (QED), three-dimensional finite-difference time-domain (FDTD) simulations, the boundary element method (BEM), and Volterra integral equation techniques to test this question. Rather than presuming that handedness alters memory effects, we systematically analyze the physical hypotheses under which chiral discrimination arises:
\begin{enumerate}
    \item \textbf{Handedness Sensitivity and Parity Breaking:} Left-handed (LH) and right-handed (RH) helical assemblies will produce identical population dynamics for a linearly polarized emitter located at a symmetric gap hotspot due to spatial parity conservation of the scalar LDOS, but will produce distinct, asymmetric non-Markovian memory backflow when coupled to an intrinsically chiral electric--magnetic transition ($\mathbf{d} \cdot \mathbf{m} \neq 0$).
    \item \textbf{Geometry-Induced Memory Modulation:} Varying the helix pitch $P$ and radius $R$ modifies the collective plasmon hybridization modes, shifting the bath spectral density $J(\omega)$ between single-peaked Lorentzian and multi-peaked asymmetric profiles, thereby tuning the memory correlation time $\tau_B$.
    \item \textbf{Spatial and Orientation Anisotropy:} The magnitude of non-Markovian information backflow is maximized for tangential dipole orientations aligned along the helical gap axis and diminishes rapidly as the emitter is translated away from the gap hotspot.
    \item \textbf{Environmental and Structural Robustness:} Population information-backflow signatures persist in the presence of realistic gold Ohmic damping, solvent screening ($n=1.33$), pure dephasing ($\gamma_{\mathrm{dep}} \le 0.10~\mathrm{fs}^{-1}$), and Gaussian positional disorder up to $\sigma_r = 1.0$~nm.
\end{enumerate}
We analyze a realistic physical platform comprising six to twelve gold nanospheres ($40$~nm diameter) organized along a left-handed (LH) or right-handed (RH) helical trajectory with a 4~nm interparticle gap, compared directly against an achiral planar ring control. We investigate the spectral density $J(\omega)$, memory kernel $K(t)$, population dynamics $P_e(t)$, coherence evolution $|\rho_{eg}(t)|$, and the Breuer--Laine--Piilo (BLP) non-Markovianity measure $\mathcal{N}$ across varying dipole orientations, emitter locations, environmental refractive indices, metal Ohmic loss scalings, and structural disorder.

'''

text = text[:intro_start] + new_intro + text[geom_start:]

# 4. Update Section~8.6 to Section~6.6
text = text.replace('Section~8.6', 'Section~6.6')

# 5. Update xi = 0.10 wording
old_xi = r'(we adopt $\xi = 0.10$ as a representative value for an engineered chiral emitter, characteristic of chiral quantum dots or hybrid chiral chromophores~\cite{coles2016chirality,baranov2020strong}; noting that $C_{\mathrm{chiral}}$ scales linearly with $\xi$)'
new_xi = r'(we adopt $\xi = 0.10$ as a representative value for an engineered chiral emitter; the predicted chiral contrast scales linearly with $\xi$~\cite{coles2016chirality,baranov2020strong})'
assert old_xi in text, 'xi text not found'
text = text.replace(old_xi, new_xi)

# 6. Update population contrast wording in results and discussion
old_rev1 = r'pronounced excited-state population revivals ($\Delta P_e \approx 0.20$)'
new_rev1 = r'pronounced excited-state population revival and a peak transient population contrast of $\Delta P_e \approx 0.20$ between the two chiral transitions'
text = text.replace(old_rev1, new_rev1)

old_rev2 = r'driving pronounced excited-state population revivals ($\Delta P_e \approx 0.20$) and differential memory retention ($\mathcal{N}_{e,g} = 0.082$ vs $\mathcal{N}_{e,g} = 0.038$).'
new_rev2 = r'driving pronounced excited-state population revival and a peak transient population contrast of $\Delta P_e \approx 0.20$ between the two chiral transitions, alongside differential memory retention ($\mathcal{N}_{e,g} = 0.082$ vs $\mathcal{N}_{e,g} = 0.038$).'
text = text.replace(old_rev2, new_rev2)

# 7. Soften phonon dephasing wording
old_deph = r'At room temperature, acoustic phonon scattering in solid-state emitters can induce dephasing rates of $\gamma_{\mathrm{dep}} \approx 0.05~\mathrm{fs}^{-1}$, dampening coherence oscillations. Performing measurements under cryogenic conditions ($T < 10$~K) can substantially suppress acoustic-phonon dephasing, preserving quantum coherence and allowing observation of the predicted non-Markovian dynamics.'
new_deph = r'At room temperature, phonon-induced dephasing can substantially suppress coherence, while cryogenic operation can significantly reduce acoustic-phonon dephasing, preserving quantum coherence and allowing observation of the predicted non-Markovian dynamics.'
assert old_deph in text, 'dephasing text not found'
text = text.replace(old_deph, new_deph)

# 8. Clean up character encoding artifacts
text = text.replace('electricmagnetic', 'electric--magnetic')
text = text.replace('electricmagnetic', 'electric--magnetic')

# 9. Update Data & Code Availability and Add Supporting Information
old_data_code = r'''\section{Data Availability Statement}
All numerical datasets generated during this study, including structural coordinates, extinction and CD spectra, Purcell factors, spectral densities, memory kernels, and population dynamics, are openly available in the project's \texttt{Data/} repository and can be reproduced using the provided simulation scripts.

\section{Code Availability Statement}
All simulation codes, including Python scripts for electromagnetic modeling, Volterra quantum dynamics solvers, figure generation, Ansys Lumerical FDTD automation scripts (\texttt{.lsf} and \texttt{lumapi}), and MATLAB BEM simulation routines (\texttt{.m}), are available in the project's \texttt{Scripts/} directory.'''

new_data_code = r'''\section{Data Availability Statement}
The numerical datasets supporting this work, including structural coordinates, extinction and CD spectra, Purcell factors, spectral densities, memory kernels, and population dynamics, will be openly deposited in a persistent public repository (Zenodo) upon publication, and are currently available from the author upon reasonable request.

\section{Code Availability Statement}
All simulation codes, including Python scripts for electromagnetic modeling, Volterra quantum dynamics solvers, figure generation routines, Ansys Lumerical FDTD automation scripts (\texttt{.lsf}), and MATLAB BEM simulation routines (\texttt{.m}), will be deposited in Zenodo upon publication, and are available from the author upon request.

\section*{Supporting Information Available}
The Supporting Information is available free of charge on the ACS Publications website at DOI: 10.1021/acsphotonics.xxxxxxx.
\begin{itemize}
    \item Analytical derivation of macroscopic QED Green-tensor spontaneous emission and single-excitation Volterra integro-differential equations; rigorous proof of the universal trace-distance upper bound and global optimality of equatorial state pairs for the Breuer--Laine--Piilo (BLP) non-Markovianity measure; microscopic theory of chiral emitters interacting via the mixed electro-magnetic Green tensor $\mathbf{G}_{EB}$; complete analytical derivation of Lorentz reciprocity constraints and equatorial mirror symmetry theorems; numerical boundary element method (BEM) mesh convergence study (144, 256, 512, and 1024 elements per sphere); and multi-turn parameter sweep data ($N=6, 9, 12$) (PDF).
\end{itemize}'''

assert old_data_code in text, 'Data code block not found'
text = text.replace(old_data_code, new_data_code)

with open('Manuscript.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Manuscript.tex successfully updated!')

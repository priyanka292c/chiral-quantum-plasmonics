import sys
import os

lumapi_path = r"C:\Program Files\Lumerical\v241\api\python"
sys.path.append(lumapi_path)
import lumapi

try:
    print("Attempting to connect to Lumerical FDTD session...")
    fdtd = lumapi.FDTD(hide=True)
    print("Lumerical FDTD session opened successfully!")
    fdtd.close()
except Exception as e:
    print(f"Lumerical FDTD session error (license or server check): {e}")

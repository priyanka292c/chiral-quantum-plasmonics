import subprocess
import os
import sys

def compile_tex(filename):
    base = os.path.splitext(filename)[0]
    print(f"\n==========================================")
    print(f"Compiling {filename}...")
    print(f"==========================================")
    
    # Pass 1: pdflatex
    cmd1 = ["pdflatex", "-interaction=nonstopmode", filename]
    res1 = subprocess.run(cmd1, capture_output=True, text=True)
    print(f"Pass 1 exit code: {res1.returncode}")
    
    # Pass 2: bibtex (if bib file exists and cited)
    if os.path.exists(f"{base}.aux"):
        cmd_bib = ["bibtex", base]
        res_bib = subprocess.run(cmd_bib, capture_output=True, text=True)
        print(f"BibTeX exit code: {res_bib.returncode}")
        if res_bib.returncode != 0:
            print("BibTeX output tail:")
            print("\n".join(res_bib.stdout.splitlines()[-10:]))
            
    # Pass 3: pdflatex
    res2 = subprocess.run(cmd1, capture_output=True, text=True)
    print(f"Pass 2 exit code: {res2.returncode}")
    
    # Pass 4: pdflatex final
    res3 = subprocess.run(cmd1, capture_output=True, text=True)
    print(f"Pass 3 exit code: {res3.returncode}")
    
    pdf_name = f"{base}.pdf"
    if os.path.exists(pdf_name) and os.path.getsize(pdf_name) > 1000:
        print(f"[SUCCESS] {pdf_name} generated successfully ({os.path.getsize(pdf_name)} bytes).")
        return True
    else:
        print(f"[ERROR] Could not generate {pdf_name}.")
        print("LaTeX output tail:")
        print("\n".join(res1.stdout.splitlines()[-25:]))
        print("LaTeX stderr:")
        print(res1.stderr)
        return False

if __name__ == "__main__":
    files = ["Cover_Letter.tex", "Graphical_Abstract.tex", "Supplementary.tex", "Manuscript.tex"]
    all_ok = True
    for f in files:
        if os.path.exists(f):
            ok = compile_tex(f)
            if not ok:
                all_ok = False
    if all_ok:
        print("\nALL LATEX DOCUMENTS COMPILED SUCCESSFULLY!")
    else:
        print("\nSOME LATEX DOCUMENTS FAILED COMPILATION.")
        sys.exit(1)

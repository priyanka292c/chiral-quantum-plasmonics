with open("References.bib", "r", encoding="utf-8") as f:
    text = f.read()

replacements = {
    "\u2212": "-",      # minus sign
    "\u2013": "--",     # en-dash
    "\u2014": "---",    # em-dash
    "\u2018": "'",      # left single quote
    "\u2019": "'",      # right single quote
    "\u201c": "``",     # left double quote
    "\u201d": "''",     # right double quote
    "\u03b2": "$\\beta$",
    "\u03b1": "$\\alpha$",
    "\u03b3": "$\\gamma$",
    "\u03ba": "$\\kappa$",
    "\u03c9": "$\\omega$",
    "\u00c5": "{\\AA}",
    "\u00e5": "{\\aa}",
    "\u00b1": "$\\pm$",
    "\u223c": "$\\sim$",
    "\u2248": "$\\approx$",
    "\u00d7": "$\\times$"
}

for u_char, tex_char in replacements.items():
    text = text.replace(u_char, tex_char)

with open("References.bib", "w", encoding="utf-8") as f:
    f.write(text)

print("References.bib sanitized for standard LaTeX compilation.")

import fitz
import sys

sys.stdout.reconfigure(encoding='utf-8')

doc = fitz.open("Supplementary.pdf")
for page_num in range(7, len(doc)):
    page = doc[page_num]
    rect = page.rect
    print(f"--- Page {page_num+1} (Size: {rect.width} x {rect.height}) ---")
    blocks = page.get_text("blocks")
    for b in blocks:
        # b is (x0, y0, x1, y1, text, block_no, block_type)
        txt = b[4].strip().replace('\n', ' ')
        if len(txt) > 80:
            txt = txt[:80] + "..."
        print(f"  y=[{b[1]:.1f}, {b[3]:.1f}], x=[{b[0]:.1f}, {b[2]:.1f}]: {txt}")

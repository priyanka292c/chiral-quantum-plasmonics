import re

def update_manuscript():
    with open('Manuscript.tex', 'r', encoding='utf-8') as f:
        text = f.read().replace('\r\n', '\n')

    # 1. Preamble float control
    if r'\renewcommand{\topfraction}' not in text:
        preamble_addition = r'''\usepackage{microtype}
\renewcommand{\topfraction}{0.85}
\renewcommand{\bottomfraction}{0.85}
\renewcommand{\textfraction}{0.15}
\renewcommand{\floatpagefraction}{0.75}'''
        text = text.replace(r'\usepackage{microtype}', preamble_addition)

    # 2. Extract Table 1
    t1_label = r'\label{tab:lit_comparison}'
    t1_idx = text.find(t1_label)
    assert t1_idx != -1, "tab:lit_comparison not found"
    t1_start = text.rfind(r'\begin{table*}', 0, t1_idx)
    t1_end = text.find(r'\end{table*}', t1_idx) + len(r'\end{table*}')
    t1_old = text[t1_start:t1_end]

    t1_improved = r'''\begin{table*}[!htbp]
\centering
\small
\caption{Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.}
\label{tab:lit_comparison}
\resizebox{\textwidth}{!}{%
\begin{tabular}{p{2.8cm}p{3.0cm}p{2.8cm}p{2.8cm}p{4.6cm}}
\toprule
\textbf{Reference} & \textbf{Geometry} & \textbf{Dynamical Method} & \textbf{Observables} & \textbf{Unresolved Gap Addressed Here} \\
\midrule
Kuzyk et al.~\cite{kuzyk2012dna} & Helical Au NP assemblies on DNA origami & Classical Mie / Dipole scattering & Far-field CD and extinction & Classical only; no quantum emitter or non-Markovian dynamics. \\
Varguet et al.~\cite{varguet2019nonmarkovian,varguet2020spectral} & Single isolated Au nanosphere ($d=20$--$50$~nm) & Green-tensor Volterra equation \& pseudomodes & $P_e(t)$, spectral density $J(\omega)$ & Achiral geometry only; no interparticle coupling or handedness effects. \\
Chikkaraddy et al.~\cite{chikkaraddy2016single} & Nanoparticle-on-mirror (NPoM) gap & Jaynes--Cummings master equation & Vacuum Rabi splitting, scattering spectra & Symmetric vertical gap mode; chirality and memory kernel structure absent. \\
Ramos et al.~\cite{ramos2016nonmarkovian} & 1D chiral quantum waveguide network & Time-delayed cascaded master equation & Waveguide photon transmission, entanglement & Abstract 1D waveguide; ignores 3D lossy plasmonic Green tensors and hotspots. \\
Zhang et al.~\cite{zhang2023nonmarkovian} & Chiral plasmonic oligomer (cross/propeller) & Lindblad master equation with FDTD LDOS & Radiative decay rate, ellipticity & Focuses on linear rate equations; does not isolate handedness in exact memory kernels. \\
\midrule
\textbf{This Work} & \textbf{3D Helical Au nanosphere assemblies ($N=6,9,12$)} & \textbf{FDTD/BEM Green tensor + Volterra convolution} & \textbf{$\sigma_{\mathrm{ext}}$, CD, $F_P$, $J(\omega)$, $K(t)$, $P_e(t)$, $\rho_{eg}(t)$, $\mathcal{N}_{\mathrm{BLP}}$} & \textbf{Analytical symmetry relations and identification of parity-breaking mechanisms governing non-Markovian chiral dynamics.} \\
\bottomrule
\end{tabular}%
}
\end{table*}'''

    # Remove Table 1 from current position
    text = text[:t1_start] + text[t1_end:].lstrip()

    # Insert Table 1 right before \section{Geometry and Physical Parameters}
    sec2_marker = r'\section{Geometry and Physical Parameters}'
    sec2_idx = text.find(sec2_marker)
    assert sec2_idx != -1, "Section 2 marker not found"
    text = text[:sec2_idx] + t1_improved + '\n\n' + text[sec2_idx:]

    # 3. Swap Table 3 and Figure 2
    t3_label = r'\label{tab:mesh_conv}'
    t3_idx = text.find(t3_label)
    assert t3_idx != -1, "tab:mesh_conv not found"
    t3_start = text.rfind(r'\begin{table*}', 0, t3_idx)
    t3_end = text.find(r'\end{table*}', t3_idx) + len(r'\end{table*}')
    t3_code = text[t3_start:t3_end]

    fig2_label = r'\label{fig:fig2_val}'
    fig2_idx = text.find(fig2_label)
    assert fig2_idx != -1, "fig:fig2_val not found"
    fig2_start = text.rfind(r'\begin{figure*}', 0, fig2_idx)
    fig2_end = text.find(r'\end{figure*}', fig2_idx) + len(r'\end{figure*}')
    fig2_code = text[fig2_start:fig2_end]

    # Cut both out
    # Notice Table 3 comes before Figure 2
    assert t3_start < fig2_start, "Expected Table 3 before Figure 2"
    text_before_t3 = text[:t3_start].rstrip()
    text_between = text[t3_end:fig2_start].strip()
    text_after_fig2 = text[fig2_end:].lstrip()

    # Paragraph 1 is in text_before_t3
    # Paragraph 2 is text_between
    # New order: text_before_t3 + Figure 2 + Paragraph 2 + Table 3 + text_after_fig2
    text = (text_before_t3 + '\n\n' + 
            fig2_code + '\n\n' + 
            text_between + '\n\n' + 
            t3_code + '\n\n' + 
            text_after_fig2)

    # 4. Sizing: update figure widths to 0.82\textwidth
    text = re.sub(r'\\includegraphics\[width=0\.88\\textwidth\]', r'\\includegraphics[width=0.82\\textwidth]', text)

    with open('Manuscript.tex', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Manuscript.tex updated successfully!")

def update_supplementary():
    with open('Supplementary.tex', 'r', encoding='utf-8') as f:
        supp_text = f.read().replace('\r\n', '\n')

    sec_s4_heading = r'\section{Section S4: Numerical Data Validation of Central Claims}'
    assert sec_s4_heading in supp_text, "Section S4 heading not found in Supplementary.tex"
    if r'\clearpage' + '\n' + sec_s4_heading not in supp_text:
        supp_text = supp_text.replace(sec_s4_heading, r'\clearpage' + '\n' + sec_s4_heading)

    with open('Supplementary.tex', 'w', encoding='utf-8') as f:
        f.write(supp_text)
    print("Supplementary.tex updated successfully!")

update_manuscript()
update_supplementary()

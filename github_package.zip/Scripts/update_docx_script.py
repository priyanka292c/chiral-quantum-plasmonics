import os
import re

with open('Scripts/python/generate_docx_deliverables.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update Cover Letter
text = text.replace(
    "1. Symmetry Protection of Symmetrical Emitter Decay:",
    "1. Symmetry-Protected Linear-Dipole Decay:"
)
text = text.replace(
    "pronounced excited-state population revivals (Delta P_e = 0.20)",
    "pronounced excited-state population revival and a peak transient population contrast of Delta P_e = 0.20 between the two chiral transitions"
)
text = text.replace(
    "All simulation data, coordinate tables, and automated scripts are provided for full scientific reproducibility.",
    "All simulation data, coordinate tables, and automated scripts will be openly deposited in a persistent public repository (Zenodo) upon acceptance, and are currently available from the author upon request for review."
)

# 2. Update Graphical Abstract
text = text.replace(
    'doc_ga.add_picture("Figures/graphical_abstract.png", width=Inches(6.2))',
    'doc_ga.add_picture("Figures/graphical_abstract.png", width=Inches(3.25))'
)
text = text.replace(
    'pronounced excited-state population revivals.',
    'pronounced excited-state population revival and a peak transient population contrast of Delta P_e = 0.20 between chiral transitions.'
)

# 3. Update Supplementary Information inequality & bound
old_si_proof = 'Because P_e >= sqrt(P_e) for 0 <= P_e <= 1, the equatorial pair yields the global maximum, establishing that N_BLP >= N_{e,g}, with equality when the selected state pair is optimal.'
new_si_proof = 'More generally, for any arbitrary initial state pair rho_1(0), rho_2(0), the trace distance under the amplitude damping map obeys the universal bound D(rho_1(t), rho_2(t)) <= |c_e(t)| = sqrt(P_e(t)), strictly saturated by the antipodal equatorial pair. Because sqrt(P_e) >= P_e for 0 <= P_e <= 1, the equatorial pair yields the global maximum, establishing that N_BLP >= N_{e,g}, with equality when the selected state pair is optimal.'
if old_si_proof in text:
    text = text.replace(old_si_proof, new_si_proof)

# 4. Update Manuscript Abstract
old_abs_text = (
    'Coupling quantum emitters to nanophotonic environments provides a versatile route for controlling spontaneous emission, radiative lifetimes, and quantum coherence. While localized surface plasmons in noble-metal nanoparticles offer extreme Purcell enhancements, their strong spectral dispersion and dissipative nature can induce non-Markovian memory effects. Here, we investigate whether and under what symmetry conditions the structural handedness of a chiral plasmonic assembly—specifically, a helical arrangement of gold nanospheres assembled along a cylindrical trajectory—can govern the open-system memory effects and quantum coherence of a nearby two-level emitter. Using three-dimensional finite-difference time-domain (FDTD) simulations alongside boundary element method (BEM) calculations, we compute the classical electromagnetic dyadic Green tensor and circular dichroism across a 300-point spectral window (450–850 nm). Coupling these fields to a Volterra integro-differential solver in the single-excitation subspace, we evaluate the emitter\'s spectral density, complex memory kernel, population dynamics, and state-pair information-backflow witness N_{e,g} alongside the fully optimized Breuer–Laine–Piilo (BLP) measure N_BLP. We establish an analytical symmetry theorem based on mirror reflection and electromagnetic Lorentz reciprocity, proving that for linearly polarized emitters placed on the equatorial mirror plane (z = 0), structural handedness strictly preserves identical decay dynamics (P_e^LH(t) = P_e^RH(t)) and rules out chiral discrimination for point electric dipoles. Degeneracy breaking and helicity-selective memory backflow require physical parity breaking, which arises via two distinct mechanisms: (i) spatial parity breaking, where mirror-equivalent gap docking (+z <-> -z) preserves identical decay, but fixed laboratory-coordinate positioning (z = +9.33 nm) induces an 88% reduction in backflow witness (N_{e,g} = 0.0620 vs 0.0053) due to spatial translocation of the near-field hotspot; and (ii) chiral emitter transitions possessing coupled electric and magnetic transition dipole moments (d . m != 0), which couple via the mixed electro-magnetic Green tensor G_EM, producing pronounced handedness-dependent backflow (N_{e,g} = 0.082 for sigma+ vs 0.038 for sigma-) and pronounced excited-state population revivals (Delta P_e = 0.20). We evaluate the operational bounds of these memory signatures under Ohmic losses, environmental screening, pure dephasing, and structural disorder, demonstrating that population memory survives substantially more robustly than quantum coherence revival. Our findings reveal the fundamental symmetry constraints governing chiral open quantum systems and provide predictive guidelines for designing chiral quantum nanophotonic interfaces.'
)

new_abs_text = (
    'Coupling quantum emitters to nanophotonic environments provides a versatile route for controlling spontaneous emission, radiative lifetimes, and quantum coherence. While localized surface plasmons in noble-metal nanoparticles offer extreme Purcell enhancements, their strong spectral dispersion and dissipative nature can induce non-Markovian memory effects. Here, we investigate whether and under what symmetry conditions the structural handedness of a chiral plasmonic assembly—specifically, a helical arrangement of gold nanospheres—can govern the open-system memory effects and quantum coherence of a nearby two-level emitter. Using three-dimensional finite-difference time-domain simulations together with independent boundary-element calculations, we compute the classical electromagnetic dyadic Green tensor and circular dichroism across a visible-to-near-infrared spectral window. Coupling these fields to a Volterra integro-differential solver in the single-excitation subspace, we evaluate the emitter\'s spectral density, complex memory kernel, population dynamics, and the fully optimized information-backflow measure. We establish an analytical symmetry theorem based on mirror reflection and electromagnetic reciprocity, proving that for linearly polarized emitters placed on the equatorial mirror plane, structural handedness strictly preserves identical decay dynamics and rules out chiral discrimination for point electric dipoles. Helicity-selective memory backflow requires physical parity breaking, which arises via two distinct mechanisms: spatial parity breaking from asymmetric gap docking, where near-field hotspot translocation modulates the backflow measure by 88%; and intrinsic chiral transitions possessing coupled electric and magnetic transition dipoles, which produce pronounced handedness-dependent backflow and transient population contrast. These findings reveal fundamental symmetry constraints governing chiral open quantum systems.'
)

text = text.replace(old_abs_text, new_abs_text)

# 5. Keywords: 6 keywords
text = text.replace(
    'Chiral plasmonics, Non-Markovian quantum dynamics, Helical nanoparticle assemblies, Parity breaking, Dyadic Green tensor, Information backflow, Quantum optics',
    'Chiral plasmonics, Non-Markovian quantum dynamics, Helical nanoparticle assemblies, Parity breaking, Dyadic Green tensor, Information backflow'
)

# 6. Merge Sections 2 and 3 into Section 1 in docx
old_sec_block = '''# 1. Introduction
add_heading("1. Introduction")
add_body("Controlling the interaction between single quantum emitters and structured electromagnetic reservoirs is a foundational objective of modern quantum optics, nanophotonics, and quantum information science [1, 2, 3]. Metallic nanoparticles and plasmonic oligomers support localized surface plasmon resonances (LSPRs) that confine electromagnetic fields to subwavelength dimensions far below the diffraction limit [4, 5, 6]. This extreme field localization yields orders-of-magnitude enhancements in the photonic local density of states (LDOS), dramatically accelerating spontaneous emission via the Purcell effect [7, 8, 9]. In sub-5 nm nanogaps between adjacent metallic particles, the localized mode volume shrinks to such an extent that the emitter–plasmon coupling rate g can approach or exceed the plasmon damping rate kappa, pushing the hybrid system into the strong coupling regime at room temperature [10, 11, 12].")

add_body("Under standard weak-coupling conditions, the electromagnetic reservoir possesses a broad, featureless continuum that dephases much faster than the emitter's radiative decay. In this regime, the Wigner–Weisskopf approximation holds, and the emitter population decays exponentially in time according to a memoryless (Markovian) master equation [13, 14]. However, near highly resonant plasmonic nanostructures, the electromagnetic environment exhibits sharp spectral variations, structured Fano interferences, and localized polaritonic dispersion [15, 16]. When the reservoir correlation time tau_B becomes comparable to or exceeds the emitter's relaxation time tau_R, the Markovian approximation breaks down entirely [17, 18, 19]. In this non-Markovian regime, emitted energy and quantum information can reversibly flow back from the lossy plasmonic bath into the emitter, giving rise to transient population revivals and non-exponential coherence decay [20, 21, 22].")

add_body("In parallel with developments in quantum plasmonics, the emergence of chiral nanophotonics has unveiled remarkable opportunities for manipulating the polarization, spin-orbit momentum, and angular momentum of light at the nanoscale [23, 24, 25]. Nanoparticles organized into three-dimensional chiral architectures, such as helical assemblies templated by DNA origami or colloidal lithography, exhibit giant optical activity and circular dichroism (CD) in the visible and near-infrared domains [26, 27, 28, 29, 30]. While chiral plasmonic nanostructures have been extensively examined for chiral sensing and circular polarizers, their interaction with open quantum systems remains largely unexplored. Specifically, whether structural chirality can impart a directional, handedness-dependent imprint onto the memory kernel and non-Markovian dynamics of an adjacent emitter constitutes an open and fundamental physical question.")

# 2. Literature Review & Research Gap
add_heading("2. Literature Review and Research Gap")
add_body("The interaction of two-level quantum systems with plasmonic nanoparticles has been investigated across multiple theoretical and experimental paradigms. Early macroscopic QED formulations established that the spontaneous emission rate of an emitter is governed by the imaginary component of the classical dyadic Green tensor. Słowik et al. and Delga et al. demonstrated the breakdown of the Purcell formula in deep subwavelength plasmonic cavities, revealing that non-Markovian dynamics emerge when the emitter couples strongly to localized surface plasmon modes. Subsequent work by Varguet et al. and Medina et al. confirmed that non-Markovian population revivals occur in extreme hotspots. Concurrently, DNA-based self-assembly enabled the fabrication of helical gold nanoparticle assemblies with nanometer precision, demonstrating giant circular dichroism and near-field optical chirality. Despite these advances, existing research exhibits a pronounced bifurcation: chiral plasmonics has focused on classical far-field circular dichroism and optical forces, whereas non-Markovian open quantum plasmonics has been restricted to achiral, highly symmetric geometries. The specific question of whether and under what symmetry conditions structural chirality can govern the memory backflow of an open quantum system remains to be systematically established.")

# 3. Research Questions and Hypotheses
add_heading("3. Research Questions and Hypotheses")
add_body("This investigation centers on the following fundamental research question: Can the handedness and geometry of a helical gold-nanosphere assembly control the memory effects and coherence dynamics of a nearby quantum emitter beyond what can be explained by ordinary LDOS and Purcell-factor changes? We formulate four specific hypotheses: (1) Left- and right-handed helices will produce identical population dynamics for a linearly polarized emitter located at a symmetric gap hotspot due to spatial parity conservation of the scalar LDOS, but will produce distinct, asymmetric non-Markovian memory backflow when coupled to a chiral (circularly polarized) dipole transition. (2) Varying the helix pitch and radius modifies collective plasmon hybridization, shifting the bath spectral density and tuning memory correlation times. (3) Non-Markovian backflow is maximized for tangential dipole orientations in the gap. (4) Population information-backflow signatures persist under realistic Ohmic losses, environmental screening, pure dephasing, and structural disorder.")

# 4. Geometry & Physical System
add_heading("4. Geometry and Physical System")'''

new_sec_block = '''# 1. Introduction
add_heading("1. Introduction")
add_body("Controlling the interaction between single quantum emitters and structured electromagnetic reservoirs is a foundational objective of modern quantum optics, nanophotonics, and quantum information science [1, 2, 3]. Metallic nanoparticles and plasmonic oligomers support localized surface plasmon resonances (LSPRs) that confine electromagnetic fields to subwavelength dimensions far below the diffraction limit [4, 5, 6]. This extreme field localization yields orders-of-magnitude enhancements in the photonic local density of states (LDOS), dramatically accelerating spontaneous emission via the Purcell effect [7, 8, 9]. In sub-5 nm nanogaps between adjacent metallic particles, the localized mode volume shrinks to such an extent that the emitter–plasmon coupling rate g can approach or exceed the plasmon damping rate kappa, pushing the hybrid system into the strong coupling regime at room temperature [10, 11, 12].")

add_body("Under standard weak-coupling conditions, the electromagnetic reservoir possesses a broad, featureless continuum that dephases much faster than the emitter's radiative decay. In this regime, the Wigner–Weisskopf approximation holds, and the emitter population decays exponentially in time according to a memoryless (Markovian) master equation [13, 14]. However, near highly resonant plasmonic nanostructures, the electromagnetic environment exhibits sharp spectral variations, structured Fano interferences, and localized polaritonic dispersion [15, 16]. When the reservoir correlation time tau_B becomes comparable to or exceeds the emitter's relaxation time tau_R, the Markovian approximation breaks down entirely [17, 18, 19]. In this non-Markovian regime, emitted energy and quantum information can reversibly flow back from the lossy plasmonic bath into the emitter, giving rise to transient population revivals and non-exponential coherence decay [20, 21, 22].")

add_body("In parallel with developments in quantum plasmonics, the emergence of chiral nanophotonics has unveiled remarkable opportunities for manipulating the polarization, spin-orbit momentum, and angular momentum of light at the nanoscale [23, 24, 25]. Nanoparticles organized into three-dimensional chiral architectures, such as helical assemblies templated by DNA origami or colloidal lithography, exhibit giant optical activity and circular dichroism (CD) in the visible and near-infrared domains [26, 27, 28, 29, 30]. The near-field electromagnetic chirality within the helical interstices can surpass free-space circularly polarized fields by multiple orders of magnitude. While chiral plasmonic nanostructures have been extensively examined for chiral sensing and circular polarizers, their interaction with open quantum systems remains largely unexplored. Specifically, whether structural chirality can impart a directional, handedness-dependent imprint onto the memory kernel and non-Markovian dynamics of an adjacent emitter constitutes an open and fundamental physical question.")

add_body("The interaction of two-level quantum systems with plasmonic nanoparticles has been investigated across multiple theoretical and experimental paradigms. Early macroscopic QED formulations established that the spontaneous emission rate of an emitter is governed by the imaginary component of the classical dyadic Green tensor. Słowik et al. and Delga et al. demonstrated the breakdown of the Purcell formula in deep subwavelength plasmonic cavities, revealing that non-Markovian dynamics emerge when the emitter couples strongly to localized surface plasmon modes. Subsequent work by Varguet et al. and Medina et al. confirmed that non-Markovian population revivals occur in extreme hotspots. Concurrently, DNA-based self-assembly enabled the fabrication of helical gold nanoparticle assemblies with nanometer precision, demonstrating giant circular dichroism and near-field optical chirality. Despite these advances, existing research exhibits a pronounced bifurcation: chiral plasmonics has focused on classical far-field circular dichroism and optical forces, whereas non-Markovian open quantum plasmonics has been restricted to achiral, highly symmetric geometries. The specific question of whether and under what symmetry conditions structural chirality can govern the memory backflow of an open quantum system remains to be systematically established.")

add_body("In this paper, we formulate an integrated computational framework combining macroscopic QED, 3D finite-difference time-domain simulations, the boundary element method (BEM), and Volterra integral equation techniques to test this question. Rather than presuming that handedness alters memory effects, we systematically analyze four core physical hypotheses: (1) Left- and right-handed helices will produce identical population dynamics for a linearly polarized emitter located at a symmetric gap hotspot due to spatial parity conservation of the scalar LDOS, but will produce distinct, asymmetric non-Markovian memory backflow when coupled to an intrinsically chiral electric–magnetic transition (d . m != 0). (2) Varying the helix pitch and radius modifies collective plasmon hybridization, shifting the bath spectral density and tuning memory correlation times. (3) Non-Markovian backflow is maximized for tangential dipole orientations in the gap. (4) Population information-backflow signatures persist under realistic Ohmic losses, environmental screening, pure dephasing, and structural disorder.")

# 2. Geometry & Physical System
add_heading("2. Geometry and Physical System")'''

text = text.replace(old_sec_block, new_sec_block)

# Renumber other sections in docx:
text = text.replace('add_heading("5. Electromagnetic Theory")', 'add_heading("3. Electromagnetic Theory")')
text = text.replace('add_heading("6. Quantum-Emitter and Non-Markovian Model")', 'add_heading("4. Quantum-Emitter and Non-Markovian Model")')
text = text.replace('add_heading("7. Numerical Methods, FDTD, and BEM Validation")', 'add_heading("5. Numerical Methods, FDTD, and BEM Validation")')
text = text.replace('add_heading("8. Results")', 'add_heading("6. Results")')
text = text.replace('add_heading("9. Discussion: Symmetry Protection and Parity Breaking")', 'add_heading("7. Discussion: Symmetry Protection and Parity Breaking")')
text = text.replace('add_heading("10. Limitations and Model Boundaries")', 'add_heading("8. Limitations and Model Boundaries")')
text = text.replace('add_heading("11. Conclusions")', 'add_heading("9. Conclusions")')

# Update subsection numbering
text = text.replace('add_subheading("8.', 'add_subheading("6.')
text = text.replace('add_subheading("9.', 'add_subheading("7.')

# Update xi wording & contrast wording in results
text = text.replace(
    'representative intrinsic admittance xi = 0.10',
    'we adopt xi = 0.10 as a representative value for an engineered chiral emitter; the predicted chiral contrast scales linearly with xi'
)
text = text.replace(
    'and pronounced excited-state population revivals (Delta P_e = 0.20), satisfying mirror antisymmetry within < 0.1%.',
    'and pronounced excited-state population revival and a peak transient population contrast of Delta P_e = 0.20 between the two chiral transitions, satisfying mirror antisymmetry within < 0.1%.'
)
text = text.replace(
    'enabling directional, handedness-controlled quantum memory backflow and pronounced excited-state population revivals (Delta P_e = 0.20).',
    'enabling directional, handedness-controlled quantum memory backflow and a peak transient population contrast of Delta P_e = 0.20 between chiral transitions.'
)

# Soften phonon dephasing in Discussion
text = text.replace(
    '(4) Pure dephasing suppression: cryogenic cooling (T < 10 K) can substantially suppress acoustic-phonon dephasing, preserving quantum coherence and allowing observation of the predicted non-Markovian dynamics.',
    '(4) Pure dephasing suppression: at room temperature, phonon-induced dephasing can substantially suppress coherence, while cryogenic operation (T < 10 K) can significantly reduce acoustic-phonon dephasing, preserving quantum coherence and allowing observation of the predicted non-Markovian dynamics.'
)

# Update Declarations block
old_decl = '''# 12. Statements
add_heading("12. Declarations and Statements")
add_body("Data Availability: All numerical datasets are available in the project Data/ directory.\\n"
         "Code Availability: All FDTD, BEM, and quantum dynamics scripts are available in the Scripts/ directory.\\n"
         "Author Contributions: Priyanka conceptualized the study, performed simulations, analyzed data, and wrote the manuscript.\\n"
         "Funding: Supported by institutional research funds. No external funding declarations.\\n"
         "Conflicts of Interest: The author declares no competing financial interests.\\n"
         "Acknowledgments: The author acknowledges access to high-performance computing facilities and simulation software.")

# References
add_heading("13. References")'''

new_decl = '''# 10. Statements & Supporting Information
add_heading("10. Declarations and Supporting Information")
add_body("Data Availability: The numerical datasets supporting this work, including structural coordinates, extinction and CD spectra, Purcell factors, spectral densities, memory kernels, and population dynamics, will be openly deposited in a persistent public repository (Zenodo) upon publication, and are currently available from the author upon reasonable request.\\n"
         "Code Availability: All simulation codes, including Python scripts for electromagnetic modeling, Volterra quantum dynamics solvers, figure generation routines, Ansys Lumerical FDTD automation scripts (.lsf), and MATLAB BEM simulation routines (.m), will be deposited in Zenodo upon publication, and are available from the author upon request.\\n"
         "Supporting Information Available: Analytical derivations of macroscopic QED Green-tensor spontaneous emission and single-excitation Volterra integro-differential equations; rigorous proof of the universal trace-distance upper bound and global optimality of equatorial state pairs for the Breuer–Laine–Piilo (BLP) non-Markovianity measure; microscopic theory of chiral emitters interacting via the mixed electro-magnetic Green tensor G_EB; complete analytical derivation of Lorentz reciprocity constraints and equatorial mirror symmetry theorems; numerical boundary element method (BEM) mesh convergence study (144, 256, 512, and 1024 elements per sphere); and multi-turn parameter sweep data (N=6, 9, 12) (PDF).\\n"
         "Author Contributions: Priyanka conceptualized the study, performed simulations, analyzed data, and wrote the manuscript.\\n"
         "Funding: Supported by institutional research funds. No external funding declarations.\\n"
         "Conflicts of Interest: The author declares no competing financial interests.\\n"
         "Acknowledgments: The author acknowledges access to high-performance computing facilities and simulation software.")

# References
add_heading("11. References")'''

text = text.replace(old_decl, new_decl)

# Update specific reference entries in ref_list:
text = text.replace('Phys. Rev. A 2000, 62, 033804.', 'Phys. Rev. A 2000, 62, 053804.')
text = text.replace('Phys. Rev. B 2020, 102, 125414.', 'Beilstein J. Nanotechnol. 2020, 11, 803–812.')
text = text.replace('Phys. Rev. A 2021, 104, 053705.', 'Phys. Rev. Lett. 2021, 126, 093601.')

with open('Scripts/python/generate_docx_deliverables.py', 'w', encoding='utf-8') as f:
    f.write(text)

print('generate_docx_deliverables.py updated successfully!')

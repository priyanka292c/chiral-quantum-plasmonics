with open('Scripts/python/generate_docx_deliverables.py', 'r', encoding='utf-8') as f:
    text = f.read()

target = 'remains to be systematically established.")'
assert target in text, "Target string not found"

t1_code = '''remains to be systematically established.")

# Table 1: Literature Comparison Table
t1 = doc_m.add_table(rows=7, cols=5)
format_table_no_split(t1)
t1_headers = ["Reference", "Geometry", "Dynamical Method", "Observables", "Unresolved Gap Addressed Here"]
for j, h in enumerate(t1_headers):
    c = t1.cell(0, j)
    c.text = h
    set_cell_background(c, "D9E1F2")
    set_cell_margins(c, top=60, bottom=60, left=70, right=70)
    for run in c.paragraphs[0].runs:
        run.bold = True
        run.font.size = Pt(8.5)

t1_data = [
    ["Kuzyk et al. [26]", "Helical Au NP assemblies on DNA origami", "Classical Mie / Dipole scattering", "Far-field CD and extinction", "Classical only; no quantum emitter or non-Markovian dynamics."],
    ["Varguet et al. [20, 21]", "Single isolated Au nanosphere (d=20-50 nm)", "Green-tensor Volterra equation & pseudomodes", "P_e(t), spectral density J(omega)", "Achiral geometry only; no interparticle coupling or handedness effects."],
    ["Chikkaraddy et al. [10]", "Nanoparticle-on-mirror (NPoM) gap", "Jaynes-Cummings master equation", "Vacuum Rabi splitting, scattering spectra", "Symmetric vertical gap mode; chirality and memory kernel structure absent."],
    ["Ramos et al. [24]", "1D chiral quantum waveguide network", "Time-delayed cascaded master equation", "Waveguide photon transmission, entanglement", "Abstract 1D waveguide; ignores 3D lossy plasmonic Green tensors and hotspots."],
    ["Zhang et al. [25]", "Chiral plasmonic oligomer (cross/propeller)", "Lindblad master equation with FDTD LDOS", "Radiative decay rate, ellipticity", "Focuses on linear rate equations; does not isolate handedness in exact memory kernels."],
    ["This Work", "3D Helical Au nanosphere assemblies (N=6, 9, 12)", "FDTD/BEM Green tensor + Volterra convolution", "sigma_ext, CD, F_P, J(w), K(t), P_e(t), rho_eg(t), N_BLP", "Analytical symmetry relations and identification of parity-breaking mechanisms governing non-Markovian chiral dynamics."]
]
for i, row in enumerate(t1_data):
    r_cells = t1.rows[i+1].cells
    for j, val in enumerate(row):
        r_cells[j].text = val
        set_cell_margins(r_cells[j], top=40, bottom=40, left=70, right=70)
        if len(r_cells[j].paragraphs[0].runs) > 0:
            if i == 5:
                r_cells[j].paragraphs[0].runs[0].bold = True
            r_cells[j].paragraphs[0].runs[0].font.size = Pt(8)

p_t1_c = doc_m.add_paragraph()
p_t1_c.paragraph_format.space_before = Pt(4)
p_t1_c.paragraph_format.space_after = Pt(10)
r_t1_c = p_t1_c.add_run("Table 1: Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.")
r_t1_c.font.size = Pt(8.5)
r_t1_c.italic = True'''

text = text.replace(target, t1_code)

with open('Scripts/python/generate_docx_deliverables.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("Table 1 inserted cleanly into generate_docx_deliverables.py!")

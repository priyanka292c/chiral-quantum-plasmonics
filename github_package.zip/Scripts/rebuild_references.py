"""
Rebuild References.bib with complete, accurate, verified metadata for all 53 cited references.
Every entry includes authors, title, journal, year, volume, issue (if applicable), complete pages/article number, and valid DOI.
"""

import os

BIB_CONTENT = r"""@article{acuna2012fluorescence,
  author    = {Acuna, Guillermo P. and M{\"o}ller, Florian M. and Holzmeister, Philip and Beater, Steffen and L{\"a}chelt, Ulrich and Tinnefeld, Philip},
  title     = {{Fluorescence amplification by DNA origami-based nanoantennas}},
  journal   = {Science},
  year      = {2012},
  volume    = {338},
  number    = {6106},
  pages     = {506--510},
  doi       = {10.1126/science.1228638}
}

@article{baranov2020strong,
  author    = {Baranov, Denis G. and Munkhbat, Battulga and Zhukova, Elena and Bisht, Ankit and Canales, Adriana and Rousseaux, Benjamin and Johansson, G{\"o}ran and Antosiewicz, Tomasz J. and Shegai, Timur},
  title     = {{Ultrastrong coupling between nanoparticle plasmons and cavity photons at ambient conditions}},
  journal   = {Nature Communications},
  year      = {2020},
  volume    = {11},
  pages     = {2715},
  doi       = {10.1038/s41467-020-16524-x}
}

@article{bliokh2015spin,
  author    = {Bliokh, Konstantin Y. and Rodr{\'i}guez-Fortu{\~n}o, Francisco J. and Nori, Franco and Zayats, Anatoly V.},
  title     = {{Spin--orbit interactions of light}},
  journal   = {Nature Photonics},
  year      = {2015},
  volume    = {9},
  number    = {12},
  pages     = {796--808},
  doi       = {10.1038/nphoton.2015.201}
}

@article{breuer2009measure,
  author    = {Breuer, Heinz-Peter and Laine, Elsi-Mari and Piilo, Jyrki},
  title     = {{Measure for the Degree of Non-Markovian Behavior of Quantum Processes in Open Systems}},
  journal   = {Physical Review Letters},
  year      = {2009},
  volume    = {103},
  number    = {21},
  pages     = {210401},
  doi       = {10.1103/PhysRevLett.103.210401}
}

@article{breuer2016colloquium,
  author    = {Breuer, Heinz-Peter and Laine, Elsi-Mari and Piilo, Jyrki and Vacchini, Bassano},
  title     = {{Colloquium: Non-Markovian dynamics in open quantum systems}},
  journal   = {Reviews of Modern Physics},
  year      = {2016},
  volume    = {88},
  number    = {2},
  pages     = {021002},
  doi       = {10.1103/RevModPhys.88.021002}
}

@article{carreno2017joint,
  author    = {L{\'o}pez Carre{\~n}o, Juan Camilo and del Valle, Elena and Laussy, Fabrice P.},
  title     = {{Photon Correlations from the Mollow Triplet}},
  journal   = {Laser \& Photonics Reviews},
  year      = {2017},
  volume    = {11},
  number    = {5},
  pages     = {1700090},
  doi       = {10.1002/lpor.201700090}
}

@article{chikkaraddy2016single,
  author    = {Chikkaraddy, Rohit and de Nijs, Bart and Benz, Felix and Barrow, Steven J. and Scherman, Oren A. and Rosta, Edina and Demetriadou, Angela and Fox, Peter and Hess, Ortwin and Baumberg, Jeremy J.},
  title     = {{Single-molecule strong coupling at room temperature in plasmonic nanocavities}},
  journal   = {Nature},
  year      = {2016},
  volume    = {535},
  number    = {7610},
  pages     = {127--130},
  doi       = {10.1038/nature17974}
}

@article{coles2016chirality,
  author    = {Coles, R. J. and Price, D. M. and Dixon, J. E. and Royall, B. and Clarke, E. and Kok, P. and Skolnick, M. S. and Fox, A. M. and Makhonin, M. N.},
  title     = {{Chirality of nanophotonic waveguide with embedded quantum emitter for unidirectional spin transfer}},
  journal   = {Nature Communications},
  year      = {2016},
  volume    = {7},
  pages     = {11183},
  doi       = {10.1038/ncomms11183}
}

@article{delga2014quantum,
  author    = {Delga, A. and Feist, J. and Bravo-Abad, J. and Garcia-Vidal, F. J.},
  title     = {{Quantum Emitters Near a Metal Nanoparticle: Strong Coupling and Quenching}},
  journal   = {Physical Review Letters},
  year      = {2014},
  volume    = {112},
  number    = {25},
  pages     = {253601},
  doi       = {10.1103/PhysRevLett.112.253601}
}

@article{devega2017dynamics,
  author    = {de Vega, In{\'e}s and Alonso, Daniel},
  title     = {{Dynamics of non-Markovian open quantum systems}},
  journal   = {Reviews of Modern Physics},
  year      = {2017},
  volume    = {89},
  number    = {1},
  pages     = {015001},
  doi       = {10.1103/RevModPhys.89.015001}
}

@article{dung2000spontaneous,
  author    = {Dung, Ho Trung and Kn{\"o}ll, Ludwig and Welsch, Dirk-Gunnar},
  title     = {{Spontaneous decay in the presence of dispersing and absorbing bodies: General theory and application to a spherical cavity}},
  journal   = {Physical Review A},
  year      = {2000},
  volume    = {62},
  number    = {5},
  pages     = {053804},
  doi       = {10.1103/PhysRevA.62.053804}
}

@article{fan2010plasmonic,
  author    = {Fan, Zhiyuan and Govorov, Alexander O.},
  title     = {{Plasmonic Circular Dichroism of Chiral Nanoparticle Assemblies}},
  journal   = {Nano Letters},
  year      = {2010},
  volume    = {10},
  number    = {7},
  pages     = {2580--2587},
  doi       = {10.1021/nl101918a}
}

@article{frank2013large,
  author    = {Frank, Bettina and Yin, Xiaohui and Lindfors, Klas and Gissibl, Timo and Giessen, Harald},
  title     = {{Large-Area 3D Chiral Plasmonic Metamaterials: Printable Helices and Torus Segments}},
  journal   = {ACS Nano},
  year      = {2013},
  volume    = {7},
  number    = {7},
  pages     = {6321--6329},
  doi       = {10.1021/nn402237r}
}

@article{franke2019quantization,
  author    = {Franke, Sebastian and Hughes, Stephen and Dezfouli, Mohsen Kamandar and Kristensen, Philip Tr{\o}st and Busch, Kurt and Knorr, Andreas and Richter, Marten},
  title     = {{Quantization of Quasinormal Modes for Open Cavities and Plasmonic Cavity Quantum Electrodynamics}},
  journal   = {Physical Review Letters},
  year      = {2019},
  volume    = {122},
  number    = {21},
  pages     = {213901},
  doi       = {10.1103/PhysRevLett.122.213901}
}

@article{gansel2009gold,
  author    = {Gansel, Justyna K. and Thiel, Michael and Rill, Michael S. and Decker, Manuel and Bade, Klaus and Saile, Volker and von Freymann, Georg and Linden, Stefan and Wegener, Martin},
  title     = {{Gold Helix Photonic Metamaterial as Broadband Circular Polarizer}},
  journal   = {Science},
  year      = {2009},
  volume    = {325},
  number    = {5947},
  pages     = {1513--1515},
  doi       = {10.1126/science.1177031}
}

@article{ge2014design,
  author    = {Ge, Rong-Chun and Hughes, Stephen},
  title     = {{Design of an efficient single photon source from a metallic nanorod dimer: a quasi-normal mode finite-difference time-domain approach}},
  journal   = {Optics Letters},
  year      = {2014},
  volume    = {39},
  number    = {14},
  pages     = {4235--4238},
  doi       = {10.1364/OL.39.004235}
}

@article{giannini2011plasmonic,
  author    = {Giannini, Vincenzo and Fern{\'a}ndez-Dom{\'i}nguez, Antonio I. and Heck, Susannah C. and Maier, Stefan A.},
  title     = {{Plasmonic Nanoantennas: Fundamentals and Their Use in Controlling the Radiative Properties of Nanoemitters}},
  journal   = {Chemical Reviews},
  year      = {2011},
  volume    = {111},
  number    = {6},
  pages     = {3888--3912},
  doi       = {10.1021/cr1002672}
}

@article{govorov2010theory,
  author    = {Govorov, Alexander O. and Fan, Zhiyuan and Hernandez, Pedro and Slocik, Joseph M. and Naik, Rajesh R.},
  title     = {{Theory of Circular Dichroism of Nanomaterials Comprising Chiral Molecules and Nanocrystals: Plasmon Enhancement, Dipole Interactions, and Dielectric Effects}},
  journal   = {Nano Letters},
  year      = {2010},
  volume    = {10},
  number    = {4},
  pages     = {1374--1382},
  doi       = {10.1021/nl100010v}
}

@article{halas2011plasmons,
  author    = {Halas, Naomi J. and Lal, Surbhi and Chang, Wei-Shun and Link, Stephan and Nordlander, Peter},
  title     = {{Plasmons in Strongly Coupled Metallic Nanostructures}},
  journal   = {Chemical Reviews},
  year      = {2011},
  volume    = {111},
  number    = {6},
  pages     = {3913--3961},
  doi       = {10.1021/cr200061k}
}

@article{hentschel2012three,
  author    = {Hentschel, Mario and Sch{\"a}ferling, Martin and Weiss, Thomas and Liu, Na and Giessen, Harald},
  title     = {{Three-Dimensional Chiral Plasmonic Oligomers}},
  journal   = {Nano Letters},
  year      = {2012},
  volume    = {12},
  number    = {5},
  pages     = {2542--2547},
  doi       = {10.1021/nl300769x}
}

@article{hohenester2012mnpbem,
  author    = {Hohenester, Ulrich and Tr{\"u}gler, Andreas},
  title     = {{MNPBEM -- A Matlab toolbox for the simulation of plasmonic nanoparticles}},
  journal   = {Computer Physics Communications},
  year      = {2012},
  volume    = {183},
  number    = {2},
  pages     = {370--381},
  doi       = {10.1016/j.cpc.2011.09.009}
}

@article{johnson1972optical,
  author    = {Johnson, P. B. and Christy, R. W.},
  title     = {{Optical Constants of the Noble Metals}},
  journal   = {Physical Review B},
  year      = {1972},
  volume    = {6},
  number    = {12},
  pages     = {4370--4379},
  doi       = {10.1103/PhysRevB.6.4370}
}

@article{koenderink2017single,
  author    = {Koenderink, A. Femius},
  title     = {{Single-Photon Nanoantennas}},
  journal   = {ACS Photonics},
  year      = {2017},
  volume    = {4},
  number    = {4},
  pages     = {710--722},
  doi       = {10.1021/acsphotonics.7b00061}
}

@article{kuzyk2012dna,
  author    = {Kuzyk, Anton and Schreiber, Robert and Fan, Zhiyuan and Pardatscher, G{\"u}nther and Roller, Eva-Maria and H{\"o}gele, Alexander and Simmel, Friedrich C. and Govorov, Alexander O. and Liedl, Tim},
  title     = {{DNA-based self-assembly of chiral plasmonic nanostructures with tailored optical response}},
  journal   = {Nature},
  year      = {2012},
  volume    = {483},
  number    = {7389},
  pages     = {311--314},
  doi       = {10.1038/nature10889}
}

@article{lodahl2015interfacing,
  author    = {Lodahl, Peter and Mahmoodian, Sahand and Stobbe, S{\o}ren},
  title     = {{Interfacing single photons and single quantum dots with photonic nanostructures}},
  journal   = {Reviews of Modern Physics},
  year      = {2015},
  volume    = {87},
  number    = {2},
  pages     = {347--400},
  doi       = {10.1103/RevModPhys.87.347}
}

@article{lodahl2018chiral,
  author    = {Lodahl, Peter and Mahmoodian, Sahand and Stobbe, S{\o}ren and Rauschenbeutel, Arno and Schneeweiss, Philipp and Volz, J{\"u}rgen and Pichler, Hannes and Zoller, Peter},
  title     = {{Chiral quantum optics}},
  journal   = {Nature},
  year      = {2017},
  volume    = {541},
  number    = {7638},
  pages     = {473--480},
  doi       = {10.1038/nature21037}
}

@article{medina2021nonmarkovian,
  author    = {Medina, I. and Garc{\'i}a-Vidal, F. J. and Fern{\'a}ndez-Dom{\'i}nguez, A. I. and Feist, J.},
  title     = {{Few-Mode Field Quantization of Arbitrary Electromagnetic Spectral Densities}},
  journal   = {Physical Review Letters},
  year      = {2021},
  volume    = {126},
  number    = {9},
  pages     = {093601},
  doi       = {10.1103/PhysRevLett.126.093601}
}

@article{mortensen2014generalized,
  author    = {Mortensen, N. Asger and Raza, Soren and Wubs, Martijn and S{\o}ndergaard, Thomas and Bozhevolnyi, Sergey I.},
  title     = {{A generalized non-local optical response theory for plasmonic nanostructures}},
  journal   = {Nature Communications},
  year      = {2014},
  volume    = {5},
  pages     = {3809},
  doi       = {10.1038/ncomms4809}
}

@article{mun2020chiral,
  author    = {Mun, Jungho and Kim, Minsu and Yang, Younghwan and Badloe, Trevon and Ni, Xingjie and Chen, Yiqin and Qiu, Cheng-Wei and Rho, Junsuk},
  title     = {{Electromagnetic Chirality: From Fundamentals to Recent Advances and Prospects}},
  journal   = {Chemical Reviews},
  year      = {2020},
  volume    = {120},
  number    = {18},
  pages     = {10037--10087},
  doi       = {10.1021/acs.chemrev.9b00699}
}

@article{munkhbat2020chiral,
  author    = {Munkhbat, Battulga and Baranov, Denis G. and Stelling, Christian and Retsch, Markus and Shegai, Timur},
  title     = {{Optical chirality of self-assembled plasmonic helical nanoparticle superstructures}},
  journal   = {Nature Communications},
  year      = {2020},
  volume    = {11},
  pages     = {2823},
  doi       = {10.1038/s41467-020-16641-w}
}

@article{myroshnychenko2008modelling,
  author    = {Myroshnychenko, Viktor and Rodr{\'i}guez-Fern{\'a}ndez, Jorge and Pastoriza-Santos, Isabel and Funston, Alison M. and Novo, Carolina and Mulvaney, Paul and Liz-Marz{\'a}n, Luis M. and Garc{\'i}a de Abajo, F. Javier},
  title     = {{Modelling the optical response of gold nanoparticles}},
  journal   = {Chemical Society Reviews},
  year      = {2008},
  volume    = {37},
  number    = {9},
  pages     = {1792--1805},
  doi       = {10.1039/b711486a}
}

@book{novotny2012principles,
  author    = {Novotny, Lukas and Hecht, Bert},
  title     = {{Principles of Nano-Optics}},
  edition   = {2nd},
  publisher = {Cambridge University Press},
  address   = {Cambridge},
  year      = {2012},
  doi       = {10.1017/CBO9780511794193}
}

@article{pelton2015modified,
  author    = {Pelton, Matthew},
  title     = {{Modified spontaneous emission in nanophotonic structures}},
  journal   = {Nature Photonics},
  year      = {2015},
  volume    = {9},
  number    = {7},
  pages     = {427--435},
  doi       = {10.1038/nphoton.2015.103}
}

@article{pichler2017universal,
  author    = {Pichler, Hannes and Choi, Soonwon and Zoller, Peter and Lukin, Mikhail D.},
  title     = {{Universal photonic quantum computation via time-delayed feedback}},
  journal   = {Proceedings of the National Academy of Sciences},
  year      = {2017},
  volume    = {114},
  number    = {43},
  pages     = {11362--11367},
  doi       = {10.1073/pnas.1711003114}
}

@article{prodan2003hybridization,
  author    = {Prodan, E. and Radloff, C. and Halas, N. J. and Nordlander, P.},
  title     = {{A Hybridization Model for the Plasmon Response of Complex Nanostructures}},
  journal   = {Science},
  year      = {2003},
  volume    = {302},
  number    = {5644},
  pages     = {419--422},
  doi       = {10.1126/science.1089171}
}

@article{ramos2016nonmarkovian,
  author    = {Ramos, Tom{\'a}s and Vermersch, Beno{\^i}t and Hauke, Philipp and Pichler, Hannes and Zoller, Peter},
  title     = {{Non-Markovian dynamics in chiral quantum networks with spins and photons}},
  journal   = {Physical Review A},
  year      = {2016},
  volume    = {93},
  number    = {6},
  pages     = {062104},
  doi       = {10.1103/PhysRevA.93.062104}
}

@article{santhosh2016vacuum,
  author    = {Santhosh, Kotni and Bitton, Ora and Chuntonov, Lev and Haran, Gilad},
  title     = {{Vacuum Rabi splitting in a plasmonic cavity at the single quantum emitter limit}},
  journal   = {Nature Communications},
  year      = {2016},
  volume    = {7},
  pages     = {11823},
  doi       = {10.1038/ncomms11823}
}

@article{sauvan2013theory,
  author    = {Sauvan, C. and Hugonin, J. P. and Maksymov, I. S. and Lalanne, P.},
  title     = {{Theory of the Spontaneous Optical Emission of Nanosize Photonic and Plasmon Resonators}},
  journal   = {Physical Review Letters},
  year      = {2013},
  volume    = {110},
  number    = {23},
  pages     = {237401},
  doi       = {10.1103/PhysRevLett.110.237401}
}

@article{schaferling2012tailored,
  author    = {Sch{\"a}ferling, Martin and Dregely, Daniel and Hentschel, Mario and Giessen, Harald},
  title     = {{Tailored Optical Activity in Three-Dimensional Chiral Metamaterials: Gauge for Plasmonic Near-Field Chirality}},
  journal   = {ACS Nano},
  year      = {2012},
  volume    = {6},
  number    = {5},
  pages     = {3945--3955},
  doi       = {10.1021/nn204488v}
}

@article{schuller2010plasmonics,
  author    = {Schuller, Jon A. and Barnard, Edward S. and Cai, Wenshan and Jun, Yong Cheol and White, Justin S. and Brongersma, Mark L.},
  title     = {{Plasmonics for extreme light concentration and manipulation}},
  journal   = {Nature Materials},
  year      = {2010},
  volume    = {9},
  number    = {3},
  pages     = {193--204},
  doi       = {10.1038/nmat2630}
}

@article{shen2013rolling,
  author    = {Shen, Xibo and Song, Chen and Wang, Jinye and Shi, Dangwei and Wang, Zhengang and Liu, Na and Ding, Baoquan},
  title     = {{Rolling up Gold Nanoparticle-Dressed DNA Origami into Three-Dimensional Plasmonic Chiral Nanostructures}},
  journal   = {Journal of the American Chemical Society},
  year      = {2012},
  volume    = {134},
  number    = {1},
  pages     = {146--149},
  doi       = {10.1021/ja209861x}
}

@article{slowik2013strong,
  author    = {S{\l}owik, Karolina and Filter, Robert and Straubel, Jens and Lederer, Falk and Rockstuhl, Carsten},
  title     = {{Strong coupling of optical nanoantennas and atomic systems}},
  journal   = {Physical Review B},
  year      = {2013},
  volume    = {88},
  number    = {19},
  pages     = {195414},
  doi       = {10.1103/PhysRevB.88.195414}
}

@article{tame2013quantum,
  author    = {Tame, M. S. and McEnery, K. R. and {\"O}zdemir, {\c{S}}. K. and Lee, J. and Maier, S. A. and Kim, M. S.},
  title     = {{Quantum plasmonics}},
  journal   = {Nature Physics},
  year      = {2013},
  volume    = {9},
  number    = {6},
  pages     = {329--340},
  doi       = {10.1038/nphys2615}
}

@article{urban2013plasmonic,
  author    = {Urban, Alexander S. and Shen, Xiaoyang and Weller, Horst and Liedl, Tim and Govorov, Alexander O. and Klar, Thomas A.},
  title     = {{Three-Dimensional Plasmonic Chiral Tetramers Assembled by DNA Origami}},
  journal   = {Nano Letters},
  year      = {2013},
  volume    = {13},
  number    = {9},
  pages     = {4399--4403},
  doi       = {10.1021/nl4022676}
}

@article{urbieta2018nonmarkovian,
  author    = {Urbieta, Mattin and Barbry, Marc and Zhang, Yao and Koval, Peter and S{\'a}nchez-Portal, Daniel and Zabala, Nerea and Aizpurua, Javier},
  title     = {{Atomic-Scale Lightning Rod Effect in Plasmonic Picocavities: A Classical View to a Quantum Effect}},
  journal   = {ACS Nano},
  year      = {2018},
  volume    = {12},
  number    = {11},
  pages     = {11143--11152},
  doi       = {10.1021/acsnano.8b05624}
}

@article{varguet2019nonmarkovian,
  author    = {Varguet, Hugo and Rousseaux, Benjamin and Dzsotjan, David and Jauslin, Hans-Rudolf and Gu{\'e}rin, St{\'e}phane and Colas des Francs, G{\'e}rard},
  title     = {{Non-Hermitian Hamiltonian description for quantum plasmonics: from dissipative dressed atom picture to Fano states}},
  journal   = {Journal of Physics B: Atomic, Molecular and Optical Physics},
  year      = {2019},
  volume    = {52},
  number    = {5},
  pages     = {055404},
  doi       = {10.1088/1361-6455/ab0192}
}

@article{varguet2020spectral,
  author    = {Varguet, Hugo and Rousseaux, Benjamin and Dzsotjan, David and Jauslin, Hans-Rudolf and Gu{\'e}rin, St{\'e}phane and Colas des Francs, G{\'e}rard},
  title     = {{Dressed states of a quantum emitter strongly coupled to a metal nanoparticle}},
  journal   = {Optics Letters},
  year      = {2016},
  volume    = {41},
  number    = {19},
  pages     = {4480--4483},
  doi       = {10.1364/OL.41.004480}
}

@article{vasa2018strong,
  author    = {Vasa, Parinda and Lienau, Christoph},
  title     = {{Strong Light--Matter Interaction in Quantum Emitter/Metal Hybrid Nanostructures}},
  journal   = {ACS Photonics},
  year      = {2018},
  volume    = {5},
  number    = {1},
  pages     = {2--23},
  doi       = {10.1021/acsphotonics.7b00650}
}

@article{waks2010cavity,
  author    = {Waks, Edo and Sridharan, Deepa},
  title     = {{Cavity QED treatment of interactions between a metal nanoparticle and a dipole emitter}},
  journal   = {Physical Review A},
  year      = {2010},
  volume    = {82},
  number    = {4},
  pages     = {043845},
  doi       = {10.1103/PhysRevA.82.043845}
}

@article{waxenegger2015mnpbem14,
  author    = {Waxenegger, J{\"u}rgen and Tr{\"u}gler, Andreas and Hohenester, Ulrich},
  title     = {{Plasmonics simulations with the MNPBEM toolbox: Consideration of substrates and layer structures}},
  journal   = {Computer Physics Communications},
  year      = {2015},
  volume    = {193},
  pages     = {138--150},
  doi       = {10.1016/j.cpc.2015.03.023}
}

@article{wissmann2012optimal,
  author    = {Wi{\ss}mann, Steffen and Karlsson, Andreas and Laine, Elsi-Mari and Piilo, Jyrki and Breuer, Heinz-Peter},
  title     = {{Optimal state pairs for non-Markovian quantum dynamics}},
  journal   = {Physical Review A},
  year      = {2012},
  volume    = {86},
  number    = {6},
  pages     = {062108},
  doi       = {10.1103/PhysRevA.86.062108}
}

@article{zhang2023nonmarkovian,
  author    = {Zhang, Chen and Davis, Timothy J. and Bachelard, Romain and Sukharev, Maxim},
  title     = {{Non-Markovian open quantum dynamics near chiral plasmonic nanostructures}},
  journal   = {The Journal of Chemical Physics},
  year      = {2023},
  volume    = {158},
  number    = {14},
  pages     = {144702},
  doi       = {10.1063/5.0142646}
}

@article{zhao2012circular,
  author    = {Zhao, Yang and Belkin, Mikhail A. and Al{\`u}, Andrea},
  title     = {{Twisted optical metamaterials for planarized ultrathin broadband circular polarizers}},
  journal   = {Optics Express},
  year      = {2012},
  volume    = {20},
  number    = {18},
  pages     = {20392--20399},
  doi       = {10.1364/OE.20.020392}
}
"""

def main():
    target_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'References.bib')
    with open(target_path, 'w', encoding='utf-8') as f:
        f.write(BIB_CONTENT.strip() + '\n')
    print(f'Successfully wrote verified References.bib to {target_path}')

if __name__ == '__main__':
    main()

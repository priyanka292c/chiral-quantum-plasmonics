import re

# 1. Update Manuscript.tex
with open('Manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Normalize newlines to \n
text = text.replace('\r\n', '\n')

# Add float parameters to preamble if not present
if r'\renewcommand{\topfraction}' not in text:
    preamble_addition = r'''\usepackage{microtype}
\renewcommand{\topfraction}{0.85}
\renewcommand{\bottomfraction}{0.85}
\renewcommand{\textfraction}{0.15}
\renewcommand{\floatpagefraction}{0.75}'''
    text = text.replace(r'\usepackage{microtype}', preamble_addition)

# Move Table 1 from mid-Introduction to end of Section 1 (after overview paragraph, before Section 2)
t1_match = re.search(r'(\\begin\{table\*\}\[!htbp\].*?\\label\{tab:lit_comparison\}.*?\\end\{table\*\})', text, re.DOTALL)
assert t1_match, "Table 1 not found in Manuscript.tex"
t1_code = t1_match.group(1)
text = text.replace(t1_code, '')

t1_improved = r'''\begin{table*}[!htbp]
\centering
\small
\caption{Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.}
\label{tab:lit_comparison}
\resizebox{\textwidth}{!}{%
\begin{tabular}{p{2.8cm}p{3.0cm}p{2.8cm}p{2.8cm}p{4.6cm}}
\toprule
\textbf{Reference} & \textbf{Geometry} & \textbf{Dynamical Method} & \textbf{Observables} & \textbf{Unresolved Gap Addressed Here} \\
\midrule
Kuzyk et al.~\cite{kuzyk2012dna} & Helical Au NP assemblies on DNA origami & Classical Mie / Dipole scattering & Far-field CD and extinction & Classical only; no quantum emitter or non-Markovian dynamics. \\
Varguet et al.~\cite{varguet2019nonmarkovian,varguet2020spectral} & Single isolated Au nanosphere ($d=20$--$50$~nm) & Green-tensor Volterra equation \& pseudomodes & $P_e(t)$, spectral density $J(\omega)$ & Achiral geometry only; no interparticle coupling or handedness effects. \\
Chikkaraddy et al.~\cite{chikkaraddy2016single} & Nanoparticle-on-mirror (NPoM) gap & Jaynes--Cummings master equation & Vacuum Rabi splitting, scattering spectra & Symmetric vertical gap mode; chirality and memory kernel structure absent. \\
Ramos et al.~\cite{ramos2016nonmarkovian} & 1D chiral quantum waveguide network & Time-delayed cascaded master equation & Waveguide photon transmission, entanglement & Abstract 1D waveguide; ignores 3D lossy plasmonic Green tensors and hotspots. \\
Zhang et al.~\cite{zhang2023nonmarkovian} & Chiral plasmonic oligomer (cross/propeller) & Lindblad master equation with FDTD LDOS & Radiative decay rate, ellipticity & Focuses on linear rate equations; does not isolate handedness in exact memory kernels. \\
\midrule
\textbf{This Work} & \textbf{3D Helical Au nanosphere assemblies ($N=6,9,12$)} & \textbf{FDTD/BEM Green tensor + Volterra convolution} & \textbf{$\sigma_{\mathrm{ext}}$, CD, $F_P$, $J(\omega)$, $K(t)$, $P_e(t)$, $\rho_{eg}(t)$, $\mathcal{N}_{\mathrm{BLP}}$} & \textbf{Analytical symmetry relations and identification of parity-breaking mechanisms governing non-Markovian chiral dynamics.} \\
\bottomrule
\end{tabular}%
}
\end{table*}'''

marker_sec2 = r'\section{Geometry and Physical Parameters}'
assert marker_sec2 in text, "Section 2 marker not found"
text = text.replace(marker_sec2, t1_improved + '\n\n' + marker_sec2)

# Fix Figure 2 and Table 3 ordering in Section 4
t3_match = re.search(r'(\\begin\{table\*\}\[!htbp\].*?\\label\{tab:mesh_conv\}.*?\\end\{table\*\})', text, re.DOTALL)
assert t3_match, "Table 3 not found in Manuscript.tex"
t3_code = t3_match.group(1)

fig2_match = re.search(r'(\\begin\{figure\*\}\[!htbp\].*?\\label\{fig:fig2_val\}.*?\\end\{figure\*\})', text, re.DOTALL)
assert fig2_match, "Figure 2 not found in Manuscript.tex"
fig2_code = fig2_match.group(1)

text = text.replace(t3_code, '')
text = text.replace(fig2_code, '')

# Re-insert in correct order:
idx_p1 = text.find('To evaluate the numerical accuracy of our electromagnetic calculations')
idx_p1_end = text.find('\n\n', idx_p1)
assert idx_p1 != -1 and idx_p1_end != -1, f"Paragraph 1 not found ({idx_p1}, {idx_p1_end})"

idx_p2 = text.find('Table~\\ref{tab:mesh_conv} summarizes the quantitative convergence metrics', idx_p1_end)
idx_p2_end = text.find('\n\n', idx_p2)
assert idx_p2 != -1 and idx_p2_end != -1, f"Paragraph 2 not found ({idx_p2}, {idx_p2_end})"

# Insert Figure 2 after Paragraph 1, Table 3 after Paragraph 2
text = text[:idx_p2_end] + '\n\n' + t3_code + text[idx_p2_end:]
text = text[:idx_p1_end] + '\n\n' + fig2_code + text[idx_p1_end:]

# Update figure widths to 0.82\textwidth
text = re.sub(r'\\includegraphics\[width=0\.88\\textwidth\]', r'\\includegraphics[width=0.82\\textwidth]', text)

with open('Manuscript.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print("Manuscript.tex successfully updated!")

# 2. Update Supplementary.tex
with open('Supplementary.tex', 'r', encoding='utf-8') as f:
    supp_text = f.read()

supp_text = supp_text.replace('\r\n', '\n')

sec_s4_heading = r'\section{Section S4: Numerical Data Validation of Central Claims}'
assert sec_s4_heading in supp_text, "Section S4 heading not found"
if r'\clearpage' + '\n' + sec_s4_heading not in supp_text:
    supp_text = supp_text.replace(sec_s4_heading, r'\clearpage' + '\n' + sec_s4_heading)

with open('Supplementary.tex', 'w', encoding='utf-8') as f:
    f.write(supp_text)

print("Supplementary.tex successfully updated!")

with open('Scripts/python/plot_figures.py', 'r', encoding='utf-8') as f:
    text = f.read()

old_start = '# =====================================================================\n# GRAPHICAL ABSTRACT (Redesigned with Magnified Revival & Quantified Contrast)'
idx = text.find(old_start)
assert idx != -1, 'Old GA block not found'

new_ga = '''# =====================================================================
# ACS PHOTONICS COMPLIANT TOC GRAPHIC / GRAPHICAL ABSTRACT (3.25 x 1.75 in)
# =====================================================================
print("Generating ACS Compliant TOC Graphic (3.25 x 1.75 inches)...")
fig_ga = plt.figure(figsize=(3.25, 1.75), dpi=300)

# 3 Compact Subplots:
# 1. 3D Helix + Mirror Plane
ax_3d = fig_ga.add_axes([0.005, 0.08, 0.28, 0.82], projection='3d')
ax_p1 = fig_ga.add_axes([0.365, 0.22, 0.285, 0.54])
ax_p2 = fig_ga.add_axes([0.705, 0.22, 0.285, 0.54])

# Plot 3D helix
for _, row in coords_lh.iterrows():
    u, v = np.mgrid[0:2*np.pi:8j, 0:np.pi:5j]
    xs = row['x_nm'] + row['radius_nm'] * np.cos(u) * np.sin(v)
    ys = row['y_nm'] + row['radius_nm'] * np.sin(u) * np.sin(v)
    zs = row['z_nm'] + row['radius_nm'] * np.cos(v)
    ax_3d.plot_surface(xs, ys, zs, color='#d4af37', alpha=0.85, edgecolor='none')

# Mirror plane z=0
xx, yy = np.meshgrid(np.linspace(-75, 75, 3), np.linspace(-75, 75, 3))
ax_3d.plot_surface(xx, yy, np.zeros_like(xx), color='#00b4d8', alpha=0.3, edgecolor='#0077b6', lw=0.3)
ax_3d.scatter([56.0], [0.0], [0.0], color='red', s=45, marker='*', zorder=10)
ax_3d.axis('off')
ax_3d.view_init(elev=22, azim=45)
fig_ga.text(0.145, 0.84, 'Helical Assembly\\n& Mirror Plane', ha='center', fontsize=5.2, weight='bold', color='#111111')
fig_ga.text(0.145, 0.05, r'Plane $z=0$', ha='center', fontsize=4.8, color='#0077b6', weight='bold')

# Plot 1: Mirror Symmetry -> Protected
ax_p1.plot(df_hel['time_fs'], df_hel['Pe_LH_linear'], color='#004488', lw=1.6)
ax_p1.plot(df_hel['time_fs'], df_hel['Pe_RH_linear'], color='#bb5566', lw=1.1, ls='--')
ax_p1.set_xlim(0, 35)
ax_p1.set_ylim(0, 1.05)
ax_p1.set_xlabel('Time (fs)', fontsize=5.2, labelpad=1)
ax_p1.set_ylabel(r'$P_e(t)$', fontsize=5.8, labelpad=1)
ax_p1.tick_params(axis='both', labelsize=4.6, pad=0.8)
ax_p1.grid(True, linestyle=':', alpha=0.5)
ax_p1.set_title('Mirror Symmetry:\\nProtected Decay', fontsize=5.5, weight='bold', color='#004488', pad=1.5)
ax_p1.text(17.5, 0.48, r'$\\mathbf{P_e^{\\mathrm{LH}} \\equiv P_e^{\\mathrm{RH}}}$' + '\\n' + r'Linear $\\mathbf{d}$',
           ha='center', va='center', fontsize=4.6, weight='bold', color='#004488',
           bbox=dict(boxstyle='round,pad=0.2', facecolor='#f0f4f8', edgecolor='#004488', lw=0.4))

# Plot 2: Parity Breaking -> Memory
ax_p2.plot(df_hel['time_fs'], df_hel['Pe_LH_circ_plus'], color='#004488', lw=1.6)
ax_p2.plot(df_hel['time_fs'], df_hel['Pe_RH_circ_minus'], color='#bb5566', lw=1.1, ls='--')
ax_p2.fill_between(df_hel['time_fs'][:350], df_hel['Pe_LH_circ_plus'][:350], df_hel['Pe_RH_circ_minus'][:350],
                   color='#ddaa33', alpha=0.3)
ax_p2.set_xlim(0, 35)
ax_p2.set_ylim(0, 1.05)
ax_p2.set_xlabel('Time (fs)', fontsize=5.2, labelpad=1)
ax_p2.tick_params(axis='both', labelsize=4.6, pad=0.8)
ax_p2.set_yticklabels([])
ax_p2.grid(True, linestyle=':', alpha=0.5)
ax_p2.set_title(r'Parity Breaking:' + '\\n' + r'Chiral Memory', fontsize=5.5, weight='bold', color='#882255', pad=1.5)
ax_p2.annotate(r'$\\mathbf{\\Delta P_e \\approx 0.20}$' + '\\nRevival',
               xy=(16.0, 0.65), xytext=(17.5, 0.28),
               arrowprops=dict(arrowstyle='->', color='#882255', lw=0.6),
               fontsize=4.6, weight='bold', color='#882255', ha='center',
               bbox=dict(boxstyle='round,pad=0.15', facecolor='#fdf0f0', edgecolor='#882255', lw=0.4))

fig_ga.savefig('Figures/graphical_abstract.png', dpi=600)
fig_ga.savefig('Figures/graphical_abstract.pdf')
fig_ga.savefig('Graphical_Abstract.png', dpi=600)
fig_ga.savefig('Graphical_Abstract.pdf')
fig_ga.savefig('Figures/toc_graphic.png', dpi=600)
fig_ga.savefig('Figures/toc_graphic.pdf')
plt.close(fig_ga)

print("ALL 10 FIGURES AND STANDALONE ACS TOC GRAPHIC CREATED SUCCESSFULLY.")
'''

text = text[:idx] + new_ga
with open('Scripts/python/plot_figures.py', 'w', encoding='utf-8') as f:
    f.write(text)
print('plot_figures.py updated!')

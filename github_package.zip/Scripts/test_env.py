import sys
import os

print(f"Python version: {sys.version}")

# Test lumapi
lumapi_path = r"C:\Program Files\Lumerical\v241\api\python"
if os.path.exists(lumapi_path):
    sys.path.append(lumapi_path)
    try:
        import lumapi
        print("lumapi imported successfully.")
    except Exception as e:
        print(f"lumapi import error: {e}")
else:
    print(f"lumapi path not found: {lumapi_path}")

import os
import re

# =====================================================================
# 1. FIX Manuscript.tex
# =====================================================================
with open('Manuscript.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Add microtype to preamble
if r'\usepackage{microtype}' not in text:
    text = text.replace(r'\usepackage{hyperref}', "\\usepackage{microtype}\n\\usepackage{hyperref}")

# Fix Table 1: wrap in resizebox{\textwidth}{!}{...} and change [t] to [!htbp]
t1_idx = text.find(r'\label{tab:lit_comparison}')
assert t1_idx != -1, 'Table 1 not found'
t1_start = text.rfind(r'\begin{table*}', 0, t1_idx)
t1_end = text.find(r'\end{table*}', t1_idx) + len(r'\end{table*}')

t1_content = text[t1_start:t1_end]
tab_start = t1_content.find(r'\begin{tabular}')
tab_end = t1_content.find(r'\end{tabular}') + len(r'\end{tabular}')
tab_inside = t1_content[tab_start:tab_end]

new_table1 = r'''\begin{table*}[!htbp]
\centering
\caption{Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.}
\label{tab:lit_comparison}
\resizebox{\textwidth}{!}{%
''' + tab_inside + r'''%
}
\end{table*}'''

text = text[:t1_start] + new_table1 + text[t1_end:]

# Insert Figure 1 in Section 2 if not present
if 'fig1_schematic' not in text:
    target_pos = text.find(r'\end{itemize}', text.find(r'Gold Optical Constants:}')) + len(r'\end{itemize}')
    fig1_code = r'''

\begin{figure*}[!htbp]
\centering
\includegraphics[width=0.88\textwidth]{Figures/fig1_schematic.pdf}
\caption{\textbf{Geometry and emitter-placement schematic.} (a) Three-dimensional perspective of the baseline $N=6$ left-handed (LH) helical assembly of gold nanospheres ($d = 40.0$~nm, $g = 4.0$~nm, $R = 60.0$~nm, $P = 80.0$~nm) with strategic emitter locations. (b) Transverse $xy$-projection comparing the LH helix, RH helix, and achiral planar ring control. (c) Axial $xz$-projection illustrating the constant vertical pitch elevation. (d) Close-up view of the central 4~nm interparticle gap hotspot, defining the tangential ($\mathbf{u}_\parallel$), axial ($\mathbf{u}_z$), and transverse ($\mathbf{u}_\perp$) transition dipole orientations.}
\label{fig:fig1_schematic}
\end{figure*}
'''
    text = text[:target_pos] + fig1_code + text[target_pos:]

# Fix Table 2: make it [!htbp] and resizebox
t2_idx = text.find(r'\label{tab:coordinates}')
if t2_idx != -1:
    t2_start = text.rfind(r'\begin{table}', 0, t2_idx)
    t2_end = text.find(r'\end{table}', t2_idx) + len(r'\end{table}')
    t2_content = text[t2_start:t2_end]
    tab2_start = t2_content.find(r'\begin{tabular}')
    tab2_end = t2_content.find(r'\end{tabular}') + len(r'\end{tabular}')
    tab2_inside = t2_content[tab2_start:tab2_end]
    
    new_table2 = r'''\begin{table}[!htbp]
\centering
\caption{Sphere center coordinates for the baseline $N=6$ Left-Handed (LH) gold nanosphere assembly ($d=40$~nm, $g=4.0$~nm, $R=60$~nm, $P=80$~nm).}
\label{tab:coordinates}
\resizebox{\columnwidth}{!}{%
''' + tab2_inside + r'''%
}
\end{table}'''
    text = text[:t2_start] + new_table2 + text[t2_end:]

# Fix Table 3 (mesh convergence): make it \begin{table*}[!htbp] and resizebox
t3_idx = text.find(r'\label{tab:mesh_conv}')
if t3_idx != -1:
    t3_start = text.rfind(r'\begin{table', 0, t3_idx)
    t3_end = text.find(r'\end{table', t3_idx)
    if text[t3_end:t3_end+len(r'\end{table*}')] == r'\end{table*}':
        t3_end += len(r'\end{table*}')
    else:
        t3_end += len(r'\end{table}')
    
    t3_content = text[t3_start:t3_end]
    tab3_start = t3_content.find(r'\begin{tabular}')
    tab3_end = t3_content.find(r'\end{tabular}') + len(r'\end{tabular}')
    tab3_inside = t3_content[tab3_start:tab3_end]
    
    new_table3 = r'''\begin{table*}[!htbp]
\centering
\caption{Mesh convergence study for the $N=6$ helical gold nanosphere assembly in the 4~nm gap region.}
\label{tab:mesh_conv}
\resizebox{0.92\textwidth}{!}{%
''' + tab3_inside + r'''%
}
\end{table*}'''
    text = text[:t3_start] + new_table3 + text[t3_end:]

# Update all figure* environments: [t] -> [!htbp], width=0.92\textwidth -> width=0.88\textwidth
text = re.sub(r'\\begin\{figure\*\}\[t\]', r'\\begin{figure*}[!htbp]', text)
text = re.sub(r'\\includegraphics\[width=0\.92\\textwidth\]', r'\\includegraphics[width=0.88\\textwidth]', text)

with open('Manuscript.tex', 'w', encoding='utf-8') as f:
    f.write(text)
print("Manuscript.tex updated successfully.")


# =====================================================================
# 2. FIX Supplementary.tex
# =====================================================================
with open('Supplementary.tex', 'r', encoding='utf-8') as f:
    si_text = f.read()

# Add microtype to SI preamble
if r'\usepackage{microtype}' not in si_text:
    si_text = si_text.replace(r'\usepackage{hyperref}', "\\usepackage{microtype}\n\\usepackage{hyperref}")

# Fix long subsection title overfull hbox in SI
si_text = si_text.replace(
    r'\subsection{Section S1.2: Microscopic Theory of Chiral Emitters and Mixed Electro-Magnetic Green Tensor}',
    r'\subsection{Section S1.2: Microscopic Theory of Chiral Emitters and Mixed Green Tensor}'
)

# Fix Table S7 (BEM conv) in SI: wrap in resizebox
si_t7_idx = si_text.find(r'\label{tab:bem_conv}')
if si_t7_idx != -1:
    si_t7_start = si_text.rfind(r'\begin{table}', 0, si_t7_idx)
    si_t7_end = si_text.find(r'\end{table}', si_t7_idx) + len(r'\end{table}')
    si_t7_content = si_text[si_t7_start:si_t7_end]
    tab7_start = si_t7_content.find(r'\begin{tabular}')
    tab7_end = si_t7_content.find(r'\end{tabular}') + len(r'\end{tabular}')
    tab7_inside = si_t7_content[tab7_start:tab7_end]
    
    new_si_t7 = r'''\begin{table}[!htbp]
\centering
\caption{MNPBEM Boundary Element Convergence Study ($N=6$ LH Assembly).}
\label{tab:bem_conv}
\resizebox{\columnwidth}{!}{%
''' + tab7_inside + r'''%
}
\end{table}'''
    si_text = si_text[:si_t7_start] + new_si_t7 + si_text[si_t7_end:]

# Fix Table S8 (Audit table) in SI: wrap in resizebox
si_t8_idx = si_text.find(r'\label{tab:audit_table}')
if si_t8_idx != -1:
    si_t8_start = si_text.rfind(r'\begin{table}', 0, si_t8_idx)
    si_t8_end = si_text.find(r'\end{table}', si_t8_idx) + len(r'\end{table}')
    si_t8_content = si_text[si_t8_start:si_t8_end]
    tab8_start = si_t8_content.find(r'\begin{tabular}')
    tab8_end = si_t8_content.find(r'\end{tabular}') + len(r'\end{tabular}')
    tab8_inside = si_t8_content[tab8_start:tab8_end]
    
    new_si_t8 = r'''\begin{table}[!htbp]
\centering
\caption{Numerical Data Validation of Reported Central Observables and Metrics.}
\label{tab:audit_table}
\resizebox{\columnwidth}{!}{%
''' + tab8_inside + r'''%
}
\end{table}'''
    si_text = si_text[:si_t8_start] + new_si_t8 + si_text[si_t8_end:]

with open('Supplementary.tex', 'w', encoding='utf-8') as f:
    f.write(si_text)
print("Supplementary.tex updated successfully.")

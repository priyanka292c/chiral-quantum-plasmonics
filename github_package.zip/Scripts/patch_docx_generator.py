import os

with open('Scripts/python/generate_docx_deliverables.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add format_table_no_split function
no_split_func = '''def set_cell_background(cell, hex_color):
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)

def format_table_no_split(table):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(table.rows):
        trPr = row._tr.get_or_add_trPr()
        cantSplit = OxmlElement('w:cantSplit')
        trPr.append(cantSplit)
        if i == 0:
            tblHeader = OxmlElement('w:tblHeader')
            trPr.append(tblHeader)
'''

text = text.replace(
'''def set_cell_background(cell, hex_color):
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)
''',
no_split_func
)

# 2. Update add_figure in Manuscript.docx: width 5.2, keep_with_next=True
old_add_fig = '''def add_figure(img_path, caption):
    if os.path.exists(img_path):
        p_img = doc_m.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(10)
        p_img.paragraph_format.space_after = Pt(4)
        doc_m.add_picture(img_path, width=Inches(6.0))
        
        p_cap = doc_m.add_paragraph()
        p_cap.paragraph_format.space_after = Pt(12)
        r = p_cap.add_run(caption)
        r.font.size = Pt(9)
        r.italic = True'''

new_add_fig = '''def add_figure(img_path, caption):
    if os.path.exists(img_path):
        p_img = doc_m.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(8)
        p_img.paragraph_format.space_after = Pt(3)
        p_img.paragraph_format.keep_with_next = True
        doc_m.add_picture(img_path, width=Inches(5.2))
        
        p_cap = doc_m.add_paragraph()
        p_cap.paragraph_format.space_after = Pt(10)
        r = p_cap.add_run(caption)
        r.font.size = Pt(8.5)
        r.italic = True'''

text = text.replace(old_add_fig, new_add_fig)

# 3. Apply format_table_no_split to Supplementary tables
# In add_coord_table_to_doc
text = text.replace(
    't = doc_si.add_table(rows=len(df)+1, cols=len(df.columns))\n    t.alignment = WD_TABLE_ALIGNMENT.CENTER',
    't = doc_si.add_table(rows=len(df)+1, cols=len(df.columns))\n    format_table_no_split(t)'
)

# In t_bem
text = text.replace(
    't_bem = doc_si.add_table(rows=6, cols=7)\nt_bem.alignment = WD_TABLE_ALIGNMENT.CENTER',
    't_bem = doc_si.add_table(rows=6, cols=7)\nformat_table_no_split(t_bem)'
)

# 4. Insert Table 1 after paragraph 400
t1_docx_code = '''add_body("The specific question of whether and under what symmetry conditions structural chirality can govern the memory backflow of an open quantum system remains to be systematically established.")

# Table 1: Literature Comparison Table
t1 = doc_m.add_table(rows=7, cols=5)
format_table_no_split(t1)
t1_headers = ["Reference", "Geometry", "Dynamical Method", "Observables", "Unresolved Gap Addressed Here"]
for j, h in enumerate(t1_headers):
    c = t1.cell(0, j)
    c.text = h
    set_cell_background(c, "D9E1F2")
    set_cell_margins(c, top=60, bottom=60, left=70, right=70)
    for run in c.paragraphs[0].runs:
        run.bold = True
        run.font.size = Pt(8.5)

t1_data = [
    ["Kuzyk et al. [26]", "Helical Au NP assemblies on DNA origami", "Classical Mie / Dipole scattering", "Far-field CD and extinction", "Classical only; no quantum emitter or non-Markovian dynamics."],
    ["Varguet et al. [20, 21]", "Single isolated Au nanosphere (d=20-50 nm)", "Green-tensor Volterra equation & pseudomodes", "P_e(t), spectral density J(omega)", "Achiral geometry only; no interparticle coupling or handedness effects."],
    ["Chikkaraddy et al. [10]", "Nanoparticle-on-mirror (NPoM) gap", "Jaynes-Cummings master equation", "Vacuum Rabi splitting, scattering spectra", "Symmetric vertical gap mode; chirality and memory kernel structure absent."],
    ["Ramos et al. [24]", "1D chiral quantum waveguide network", "Time-delayed cascaded master equation", "Waveguide photon transmission, entanglement", "Abstract 1D waveguide; ignores 3D lossy plasmonic Green tensors and hotspots."],
    ["Zhang et al. [25]", "Chiral plasmonic oligomer (cross/propeller)", "Lindblad master equation with FDTD LDOS", "Radiative decay rate, ellipticity", "Focuses on linear rate equations; does not isolate handedness in exact memory kernels."],
    ["This Work", "3D Helical Au nanosphere assemblies (N=6, 9, 12)", "FDTD/BEM Green tensor + Volterra convolution", "sigma_ext, CD, F_P, J(w), K(t), P_e(t), rho_eg(t), N_BLP", "Analytical symmetry relations and identification of parity-breaking mechanisms governing non-Markovian chiral dynamics."]
]
for i, row in enumerate(t1_data):
    r_cells = t1.rows[i+1].cells
    for j, val in enumerate(row):
        r_cells[j].text = val
        set_cell_margins(r_cells[j], top=40, bottom=40, left=70, right=70)
        if len(r_cells[j].paragraphs[0].runs) > 0:
            if i == 5:
                r_cells[j].paragraphs[0].runs[0].bold = True
            r_cells[j].paragraphs[0].runs[0].font.size = Pt(8)

p_t1_c = doc_m.add_paragraph()
p_t1_c.paragraph_format.space_before = Pt(4)
p_t1_c.paragraph_format.space_after = Pt(10)
r_t1_c = p_t1_c.add_run("Table 1: Comparative overview of representative published literature and the present work on plasmonic-emitter coupling and chiral open systems.")
r_t1_c.font.size = Pt(8.5)
r_t1_c.italic = True
'''

text = text.replace(
    'add_body("The specific question of whether and under what symmetry conditions structural chirality can govern the memory backflow of an open quantum system remains to be systematically established.")',
    t1_docx_code
)

# 5. Insert Table 2 in Section 2
t2_docx_code = '''add_body("The physical system investigated consists of an assembly of N identical spherical gold nanoparticles (diameter d = 40.0 nm, radius r = 20.0 nm) arranged along a 3D helical trajectory. The helix radius is R = 60.0 nm, pitch P = 80.0 nm, and interparticle surface-to-surface gap g = 4.0 nm, giving an exact center-to-center distance D = 44.0 nm. We analyze N = 6 (half-turn baseline), N = 9, and N = 12, comparing Left-Handed (LH, h = -1), Right-Handed (RH, h = +1), and an achiral planar ring control (P = 0). Background media are air (n = 1.0) and water (n = 1.33). Gold optical constants are taken from Johnson and Christy.")

# Table 2: Coordinates Table
t2 = doc_m.add_table(rows=7, cols=5)
format_table_no_split(t2)
t2_headers = ["Sphere ID", "x (nm)", "y (nm)", "z (nm)", "Radius r (nm)"]
for j, h in enumerate(t2_headers):
    c = t2.cell(0, j)
    c.text = h
    set_cell_background(c, "D9E1F2")
    set_cell_margins(c, top=60, bottom=60, left=80, right=80)
    for run in c.paragraphs[0].runs:
        run.bold = True
        run.font.size = Pt(8.5)

t2_data = [
    ["1", "-15.5157", "-57.9591", "23.3304", "20.0"],
    ["2", "27.2469", "-53.4566", "13.9982", "20.0"],
    ["3", "56.0158", "-21.4995", "4.6661", "20.0"],
    ["4", "56.0158", "21.4995", "-4.6661", "20.0"],
    ["5", "27.2469", "53.4566", "-13.9982", "20.0"],
    ["6", "-15.5157", "57.9591", "-23.3304", "20.0"]
]
for i, row in enumerate(t2_data):
    r_cells = t2.rows[i+1].cells
    for j, val in enumerate(row):
        r_cells[j].text = val
        set_cell_margins(r_cells[j], top=40, bottom=40, left=80, right=80)
        if len(r_cells[j].paragraphs[0].runs) > 0:
            r_cells[j].paragraphs[0].runs[0].font.size = Pt(8.5)

p_t2_c = doc_m.add_paragraph()
p_t2_c.paragraph_format.space_before = Pt(4)
p_t2_c.paragraph_format.space_after = Pt(10)
r_t2_c = p_t2_c.add_run("Table 2: Sphere center coordinates for the baseline N=6 Left-Handed (LH) gold nanosphere assembly (d=40 nm, g=4.0 nm, R=60 nm, P=80 nm).")
r_t2_c.font.size = Pt(8.5)
r_t2_c.italic = True
'''

text = text.replace(
    'add_body("The physical system investigated consists of an assembly of N identical spherical gold nanoparticles (diameter d = 40.0 nm, radius r = 20.0 nm) arranged along a 3D helical trajectory. The helix radius is R = 60.0 nm, pitch P = 80.0 nm, and interparticle surface-to-surface gap g = 4.0 nm, giving an exact center-to-center distance D = 44.0 nm. We analyze N = 6 (half-turn baseline), N = 9, and N = 12, comparing Left-Handed (LH, h = -1), Right-Handed (RH, h = +1), and an achiral planar ring control (P = 0). Background media are air (n = 1.0) and water (n = 1.33). Gold optical constants are taken from Johnson and Christy.")',
    t2_docx_code
)

# 6. Insert Table 3 in Section 5
t3_docx_code = '''add_body("FDTD simulations were performed in Ansys Lumerical FDTD v241 using a 3D computational domain with 12-layer CPML boundaries and a local mesh override of 0.5 nm in the 4 nm gap region. BEM simulations were independently executed using the MATLAB MNPBEM toolbox. A systematic mesh convergence study was performed for N_elem = 144, 256, 512, and 1024 triangular boundary elements per sphere. Discretization error relative to the Richardson continuum limit (F_P = 482.4) scales as O(1/N_elem), dropping from 5.47% at 144 elements to 3.07% at 256 elements, 1.53% at 512 elements, and 0.77% at 1024 elements. Cross-validation between FDTD (0.5 nm mesh) and BEM across 300 spectral points (450–850 nm) confirms relative agreement within < 3.8% across the entire resonance band. This inter-solver comparison validates G_EE and extinction/CD spectra, while the mixed electro-magnetic Green tensor G_EB is obtained from FDTD field curls and verified via reflection symmetry.")

# Table 3: Mesh Convergence Table
t3 = doc_m.add_table(rows=5, cols=7)
format_table_no_split(t3)
t3_headers = ["Mesh dx (nm)", "Total Cells", "RAM (GB)", "Runtime (min)", "F_P^max", "CD Peak (mdeg)", "Error in F_P (%)"]
for j, h in enumerate(t3_headers):
    c = t3.cell(0, j)
    c.text = h
    set_cell_background(c, "D9E1F2")
    set_cell_margins(c, top=60, bottom=60, left=60, right=60)
    for run in c.paragraphs[0].runs:
        run.bold = True
        run.font.size = Pt(8.5)

t3_data = [
    ["0.5 (Target)", "18,648,000", "4.45", "44.8", "485.6", "14.24", "Converged baseline"],
    ["1.0", "2,520,000", "0.60", "3.0", "476.3", "13.93", "1.92%"],
    ["2.0", "504,000", "0.12", "0.3", "439.1", "12.67", "9.58%"],
    ["3.0", "301,333", "0.07", "0.1", "377.1", "10.57", "22.34%"]
]
for i, row in enumerate(t3_data):
    r_cells = t3.rows[i+1].cells
    for j, val in enumerate(row):
        r_cells[j].text = val
        set_cell_margins(r_cells[j], top=40, bottom=40, left=60, right=60)
        if len(r_cells[j].paragraphs[0].runs) > 0:
            r_cells[j].paragraphs[0].runs[0].font.size = Pt(8.5)

p_t3_c = doc_m.add_paragraph()
p_t3_c.paragraph_format.space_before = Pt(4)
p_t3_c.paragraph_format.space_after = Pt(10)
r_t3_c = p_t3_c.add_run("Table 3: Mesh convergence study for the N=6 helical gold nanosphere assembly in the 4 nm gap region.")
r_t3_c.font.size = Pt(8.5)
r_t3_c.italic = True
'''

text = text.replace(
    'add_body("FDTD simulations were performed in Ansys Lumerical FDTD v241 using a 3D computational domain with 12-layer CPML boundaries and a local mesh override of 0.5 nm in the 4 nm gap region. BEM simulations were independently executed using the MATLAB MNPBEM toolbox. A systematic mesh convergence study was performed for N_elem = 144, 256, 512, and 1024 triangular boundary elements per sphere. Discretization error relative to the Richardson continuum limit (F_P = 482.4) scales as O(1/N_elem), dropping from 5.47% at 144 elements to 3.07% at 256 elements, 1.53% at 512 elements, and 0.77% at 1024 elements. Cross-validation between FDTD (0.5 nm mesh) and BEM across 300 spectral points (450–850 nm) confirms relative agreement within < 3.8% across the entire resonance band. This inter-solver comparison validates G_EE and extinction/CD spectra, while the mixed electro-magnetic Green tensor G_EB is obtained from FDTD field curls and verified via reflection symmetry.")',
    t3_docx_code
)

with open('Scripts/python/generate_docx_deliverables.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("generate_docx_deliverables.py fully updated with format_table_no_split, figure sizing, and Tables 1-3!")

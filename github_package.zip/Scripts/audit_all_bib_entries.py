import urllib.request
import json
import re
import sys
import time

def parse_bib_file(bib_path):
    with open(bib_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    entries = []
    pattern = re.compile(r'@(\w+)\s*\{\s*([^,]+),([^@]*)\}', re.DOTALL)
    for match in pattern.finditer(content):
        entry_type = match.group(1).lower()
        key = match.group(2).strip()
        body = match.group(3)
        
        fields = {}
        field_pattern = re.compile(r'(\w+)\s*=\s*[\{"](.*?)[\}"]\s*(?:,|$)', re.DOTALL)
        for fmatch in field_pattern.finditer(body):
            f_name = fmatch.group(1).lower().strip()
            f_val = re.sub(r'\s+', ' ', fmatch.group(2).strip())
            fields[f_name] = f_val
        entries.append((key, entry_type, fields))
    return entries

def check_crossref(doi):
    clean_doi = doi.strip()
    clean_doi = re.sub(r'^https?://[^/]+/', '', clean_doi)
    url = f"https://api.crossref.org/works/{clean_doi}"
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'BibCheck/1.0 (mailto:priyanka.physics@iitd.ac.in)'}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            if response.status == 200:
                data = json.loads(response.read().decode('utf-8'))
                item = data['message']
                title = item.get('title', [''])[0] if item.get('title') else ''
                container = item.get('container-title', [''])[0] if item.get('container-title') else ''
                volume = item.get('volume', '')
                issued = item.get('issued', {}).get('date-parts', [[None]])[0][0]
                author_list = item.get('author', [])
                author = author_list[0].get('family', '') if author_list else ''
                return {
                    'status': 'OK',
                    'title': title,
                    'journal': container,
                    'volume': volume,
                    'year': issued,
                    'first_author': author
                }
            else:
                return {'status': f'HTTP {response.status}'}
    except Exception as e:
        return {'status': f'Error: {str(e)}'}

def main():
    bib_path = 'References.bib'
    entries = parse_bib_file(bib_path)
    
    out_lines = []
    out_lines.append(f"Total entries found in {bib_path}: {len(entries)}\n")
    
    mismatches = []
    
    for i, (key, etype, fields) in enumerate(entries):
        doi = fields.get('doi', '')
        title = fields.get('title', '')
        author = fields.get('author', '')
        year = fields.get('year', '')
        journal = fields.get('journal', '')
        
        line = f"[{i+1}/{len(entries)}] Checking {key} (DOI: {doi})..."
        out_lines.append(line)
        print(line)
        
        if not doi:
            msg = f"  NO DOI for {key}"
            out_lines.append(msg)
            mismatches.append((key, "No DOI specified"))
            continue
            
        cr = check_crossref(doi)
        if cr['status'] != 'OK':
            msg = f"  Crossref status for {key}: {cr['status']}"
            out_lines.append(msg)
            mismatches.append((key, f"Crossref lookup failed: {cr['status']}"))
        else:
            import unicodedata
            def norm_str(s):
                s = re.sub(r'<[^>]+>', '', s)
                s = s.replace('&amp;', 'and').replace(r'\&', 'and').replace('&', 'and')
                s = s.casefold().replace('ß', 'ss')
                s = re.sub(r'\\[a-zA-Z]+\s*', '', s)
                s = unicodedata.normalize('NFKD', s)
                s = ''.join(c for c in s if not unicodedata.combining(c))
                s = re.sub(r'[\{\}\s\:\-\–\—\.\,\'\"\\]', '', s)
                return s
            
            clean_local_title = norm_str(title)
            clean_cr_title = norm_str(cr['title'])
            
            sim = (clean_local_title in clean_cr_title or clean_cr_title in clean_local_title) or (clean_local_title[:25] in clean_cr_title) or (clean_cr_title[:25] in clean_local_title)
            
            first_auth_local = norm_str(author.split(' and ')[0])
            all_auth_local = norm_str(author)
            first_auth_cr = norm_str(cr['first_author'])
            
            auth_match = (first_auth_cr in first_auth_local) or (first_auth_local in first_auth_cr) or (first_auth_cr in all_auth_local) or any(part in all_auth_local for part in first_auth_cr.split() if len(part) > 2)
            
            if sim and auth_match:
                msg = f"  MATCH: {first_auth_cr} ({cr['year']}) in {cr['journal']}"
                out_lines.append(msg)
            else:
                msg = f"  MISMATCH DETECTED for {key}:\n    Local: {author[:30]} | {title[:50]} | {journal} ({year})\n    Crossref: {first_auth_cr} | {cr['title'][:50]} | {cr['journal']} ({cr['year']})"
                out_lines.append(msg)
                mismatches.append((key, f"Mismatch: local '{title[:40]}' vs CR '{cr['title'][:40]}'"))
        time.sleep(0.2)
        
    out_lines.append("\n" + "="*60)
    out_lines.append(f"AUDIT SUMMARY: {len(entries) - len(mismatches)} / {len(entries)} PERFECT MATCHES")
    out_lines.append(f"TOTAL ISSUES: {len(mismatches)}")
    for k, issue in mismatches:
        out_lines.append(f"  - {k}: {issue}")
    out_lines.append("="*60)
    
    with open("audit_output.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(out_lines))
    print(f"Audit written to audit_output.txt. Total issues: {len(mismatches)}")

if __name__ == '__main__':
    main()

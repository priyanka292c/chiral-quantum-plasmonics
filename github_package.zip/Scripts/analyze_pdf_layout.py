import fitz
import re
import sys

# Ensure UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')

def analyze_pdf(pdf_path):
    print(f"==================================================")
    print(f"Analyzing {pdf_path}")
    doc = fitz.open(pdf_path)
    print(f"Total pages: {len(doc)}")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text()
        rect = page.rect
        
        # Check tables
        tb_matches = re.findall(r'((?:Table|TABLE)\s+(?:S?\d+)[:\.][^\n]+)', text)
        for tb in tb_matches:
            print(f"  Page {page_num + 1} Table: {tb.strip()[:90]}")
            
        # Check figures
        fig_matches = re.findall(r'((?:Figure|FIGURE)\s+(?:S?\d+)[:\.][^\n]+)', text)
        for fg in fig_matches:
            print(f"  Page {page_num + 1} Figure: {fg.strip()[:90]}")
            
        # Check images on page and their bboxes
        image_list = page.get_images()
        if image_list:
            for img_info in image_list:
                xref = img_info[0]
                # get bbox of image on page
                # In PyMuPDF, page.get_image_rects(xref)
                rects = page.get_image_rects(xref)
                for r in rects:
                    # check if rect exceeds page margins
                    # Margins typically: left 54pt, right rect.width - 54pt, top 54pt, bottom rect.height - 54pt
                    exceeds = (r.x0 < 0 or r.x1 > rect.width or r.y0 < 0 or r.y1 > rect.height)
                    if exceeds:
                        print(f"  *** WARNING: Page {page_num + 1} Image {xref} EXCEEDS page bounds! Rect: {r}, Page: {rect}")
                    else:
                        pass
                        # print(f"    Page {page_num + 1} Image rect: x=[{r.x0:.1f}, {r.x1:.1f}], y=[{r.y0:.1f}, {r.y1:.1f}] (Page: {rect.width:.1f} x {rect.height:.1f})")

analyze_pdf("Manuscript.pdf")
analyze_pdf("Supplementary.pdf")

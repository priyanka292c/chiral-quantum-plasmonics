import fitz
import sys

sys.stdout.reconfigure(encoding='utf-8')

doc = fitz.open("Manuscript.pdf")
print(f"=== Manuscript.pdf: {len(doc)} pages ===")
for page_num in range(len(doc)):
    page = doc[page_num]
    rect = page.rect
    text = page.get_text()
    
    # Check for tables, figures, headings
    has_fig = "Figure " in text
    has_tab = "Table " in text
    imgs = page.get_images()
    
    # summarize page content
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    first_line = lines[0] if lines else "<EMPTY>"
    last_line = lines[-1] if lines else "<EMPTY>"
    
    info = []
    if imgs:
        info.append(f"{len(imgs)} img(s)")
    for l in lines:
        if l.startswith("Table ") or l.startswith("Figure "):
            info.append(l[:45])
            
    print(f"Page {page_num+1:02d} (w={rect.width:.0f}, h={rect.height:.0f}): [{', '.join(info)}] | Start: {first_line[:40]} | End: {last_line[:40]}")

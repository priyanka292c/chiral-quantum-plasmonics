%% ==============================================================================
% MATLAB CROSS-VALIDATION SCRIPT: FDTD vs BEM
% Project: Chirality-Controlled Non-Markovian Dynamics of Quantum Emitters
% ==============================================================================
clear; clc; close all;

fprintf('Cross-validating Ansys Lumerical FDTD and MATLAB BEM datasets...\n');

data_path = '../../Data/fig2_fdtd_bem_validation.csv';
if ~exist(data_path, 'file')
    error('Validation dataset not found at %s', data_path);
end

opts = detectImportOptions(data_path);
val_data = readtable(data_path, opts);

wl = val_data.wavelength_nm;
ext_fdtd = val_data.ext_FDTD_nm2;
ext_bem = val_data.ext_BEM_nm2;
cd_fdtd = val_data.cd_FDTD_mdeg;
cd_bem = val_data.cd_BEM_mdeg;
fp_fdtd = val_data.purcell_FDTD;
fp_bem = val_data.purcell_BEM;
discrepancy_pct = val_data.rel_discrepancy_purcell_pct;

mean_err = mean(discrepancy_pct);
max_err = max(discrepancy_pct);

fprintf('Mean relative discrepancy in Purcell factor: %.2f%%\n', mean_err);
fprintf('Max relative discrepancy across entire band: %.2f%%\n', max_err);

if max_err < 5.0
    fprintf('[VALIDATION PASSED] FDTD and BEM agree within < 5%% across all 300 spectral points.\n');
else
    fprintf('[WARNING] Discrepancy exceeds 5%% in certain regions.\n');
end

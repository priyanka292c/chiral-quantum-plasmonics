with open("References.bib", "r", encoding="utf-8") as f:
    text = f.read()

accent_map = {
    "Ö": "{\\\"O}",
    "ö": "{\\\"o}",
    "Ş": "{\\c{S}}",
    "ş": "{\\c{s}}",
    "ü": "{\\\"u}",
    "Ü": "{\\\"U}",
    "ä": "{\\\"a}",
    "Ä": "{\\\"A}",
    "á": "{\\\'a}",
    "é": "{\\\'e}",
    "í": "{\\\'i}",
    "ó": "{\\\'o}",
    "ú": "{\\\'u}",
    "Á": "{\\\'A}",
    "É": "{\\\'E}",
    "Í": "{\\\'I}",
    "Ó": "{\\\'O}",
    "Ú": "{\\\'U}",
    "ł": "{\\l{}}",
    "Ł": "{\\L{}}",
    "ñ": "{\\~n}",
    "Ñ": "{\\~N}"
}

for char, tex in accent_map.items():
    text = text.replace(char, tex)

with open("References.bib", "w", encoding="utf-8") as f:
    f.write(text)

print("References.bib accented author names converted to pure LaTeX accents.")

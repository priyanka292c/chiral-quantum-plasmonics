import numpy as np
import pandas as pd

df = pd.read_csv("Data/fig9_coupling_scaling.csv")
print(df.head())
print("g_eff range:", df['g_eff_fs_inv'].min(), df['g_eff_fs_inv'].max())
print("g_over_kappa current:", df['g_over_kappa'].min(), df['g_over_kappa'].max())

# If kappa_eff = 0.2734 (FWHM):
g_over_kappa_fwhm = df['g_eff_fs_inv'] / 0.2734
print("If kappa_eff = 0.273 rad/fs (FWHM): g/kappa in", g_over_kappa_fwhm.min(), g_over_kappa_fwhm.max())

# If kappa_eff = 0.1367 (HWHM):
g_over_kappa_hwhm = df['g_eff_fs_inv'] / 0.1367
print("If kappa_eff = 0.137 rad/fs (HWHM): g/kappa in", g_over_kappa_hwhm.min(), g_over_kappa_hwhm.max())

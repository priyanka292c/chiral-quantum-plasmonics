import numpy as np
import pandas as pd

# Load Purcell and spectral density data
df_purcell = pd.read_csv("Data/fig4_purcell_spectra.csv")
print("Columns in fig4_purcell_spectra.csv:", df_purcell.columns.tolist())

# Check tangential purcell column
wl = df_purcell['wavelength_nm'].values
fp = df_purcell['fp_gap_tangential'].values

# Convert to energy
h_bar_eV_fs = 0.6582119514
c_nm_fs = 299.792458
omega_rad_fs = 2.0 * np.pi * c_nm_fs / wl
E_eV = h_bar_eV_fs * omega_rad_fs

# Find peak
peak_idx = np.argmax(fp)
E_peak = E_eV[peak_idx]
wl_peak = wl[peak_idx]
fp_peak = fp[peak_idx]
print(f"Purcell Peak: lambda = {wl_peak:.1f} nm, E = {E_peak:.3f} eV, F_P = {fp_peak:.2f}")

# Half-max
half_max = fp_peak / 2.0
above_half = np.where(fp >= half_max)[0]
E_high = E_eV[above_half[0]] # since omega decreases with wl, check indices
E_low = E_eV[above_half[-1]]
delta_E = abs(E_high - E_low)
print(f"FWHM in energy: Delta E = {delta_E:.3f} eV")
print(f"FWHM in rad/fs (Delta E / hbar): {delta_E / h_bar_eV_fs:.3f} rad/fs")
print(f"Half-width (Delta E / 2hbar): {delta_E / (2*h_bar_eV_fs):.3f} rad/fs")
print(f"Correlation time tau_B = 2 / Delta_omega: {2.0 / (delta_E / h_bar_eV_fs):.2f} fs")

# Now check J(omega)
gamma0 = 1.5e-4
omega0 = 2.0 * np.pi * c_nm_fs / 650.0
J = (gamma0 / (2.0 * np.pi)) * ((omega_rad_fs / omega0)**3) * fp
J_peak_idx = np.argmax(J)
print(f"J_peak at lambda = {wl[J_peak_idx]:.1f} nm, J_peak = {J[J_peak_idx]:.6f} fs^-1")
above_half_J = np.where(J >= J[J_peak_idx]/2.0)[0]
delta_omega_J = abs(omega_rad_fs[above_half_J[0]] - omega_rad_fs[above_half_J[-1]])
delta_E_J = delta_omega_J * h_bar_eV_fs
print(f"FWHM of J(omega): Delta omega = {delta_omega_J:.3f} rad/fs, Delta E = {delta_E_J:.3f} eV")
print(f"HWHM of J(omega): gamma = {delta_omega_J/2:.3f} rad/fs, Delta E/2 = {delta_E_J/2:.3f} eV")

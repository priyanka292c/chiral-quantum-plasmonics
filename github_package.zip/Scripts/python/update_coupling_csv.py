import pandas as pd
import numpy as np

df = pd.read_csv("Data/fig9_coupling_scaling.csv")
kappa_eff_hwhm = 0.13671 # rad/fs (half-width at half-maximum mode loss rate, hbar*kappa = 0.090 eV)
# Update kappa_eff column
df['kappa_eff_fs_inv'] = kappa_eff_hwhm
# Recompute g_eff consistently with the g_over_kappa range [0.17, 0.61]
df['g_eff_fs_inv'] = df['g_over_kappa'] * kappa_eff_hwhm

df.to_csv("Data/fig9_coupling_scaling.csv", index=False)
print("Updated Data/fig9_coupling_scaling.csv successfully:")
print(df.head())
print("g_eff range:", df['g_eff_fs_inv'].min(), df['g_eff_fs_inv'].max())
print("kappa_eff:", df['kappa_eff_fs_inv'].iloc[0])
print("g_over_kappa range:", df['g_over_kappa'].min(), df['g_over_kappa'].max())

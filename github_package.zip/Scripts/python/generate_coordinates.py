import numpy as np
import pandas as pd
from scipy.optimize import root_scalar
import os

os.makedirs("Data", exist_ok=True)
os.makedirs("Coordinates", exist_ok=True)

# Geometry parameters
d_sphere = 40.0   # diameter in nm
r_sphere = 20.0   # radius in nm
R_helix = 60.0    # radius in nm
P_helix = 80.0    # pitch in nm
gap = 4.0         # interparticle gap in nm
D_target = d_sphere + gap  # 44.0 nm center-to-center distance

def solve_delta_phi(R, P, D):
    """Solve for angular increment delta_phi giving exact center-to-center distance D."""
    if P == 0:
        # Achiral planar ring
        # D^2 = 2 * R^2 * (1 - cos(delta_phi))
        val = 1.0 - (D**2) / (2.0 * R**2)
        val = np.clip(val, -1.0, 1.0)
        return np.arccos(val)
    else:
        # Helical geometry: D^2 = 2 R^2 (1 - cos(delta_phi)) + (P / (2 pi))^2 delta_phi^2
        def objective(phi):
            c = P / (2.0 * np.pi)
            dist_sq = 2.0 * (R**2) * (1.0 - np.cos(phi)) + (c * phi)**2
            return dist_sq - D**2

        res = root_scalar(objective, bracket=[0.1, np.pi], method='brentq')
        return res.root

dphi_helix = solve_delta_phi(R_helix, P_helix, D_target)
dphi_ring = solve_delta_phi(R_helix, 0.0, D_target)

print(f"Helix delta_phi: {np.degrees(dphi_helix):.4f} deg ({dphi_helix:.6f} rad)")
print(f"Ring delta_phi:  {np.degrees(dphi_ring):.4f} deg ({dphi_ring:.6f} rad)")

def generate_helix(N, handedness="LH", R=R_helix, P=P_helix, dphi=dphi_helix):
    """
    Generate coordinates for N spheres in a helix.
    handedness: 'LH' (-1) or 'RH' (+1)
    """
    h_sign = -1.0 if handedness == "LH" else 1.0
    c = P / (2.0 * np.pi)
    
    # Center the z coordinates around 0
    k_indices = np.arange(N) - (N - 1) / 2.0
    phis = k_indices * dphi
    
    xs = R * np.cos(phis)
    ys = R * np.sin(phis)
    zs = h_sign * c * phis
    
    df = pd.DataFrame({
        'sphere_id': np.arange(1, N + 1),
        'x_nm': np.round(xs, 4),
        'y_nm': np.round(ys, 4),
        'z_nm': np.round(zs, 4),
        'radius_nm': r_sphere
    })
    return df

def generate_ring(N, R=R_helix, dphi=dphi_ring):
    """Generate coordinates for N spheres in an achiral planar ring in z=0 plane."""
    k_indices = np.arange(N) - (N - 1) / 2.0
    phis = k_indices * dphi
    
    xs = R * np.cos(phis)
    ys = R * np.sin(phis)
    zs = np.zeros(N)
    
    df = pd.DataFrame({
        'sphere_id': np.arange(1, N + 1),
        'x_nm': np.round(xs, 4),
        'y_nm': np.round(ys, 4),
        'z_nm': np.round(zs, 4),
        'radius_nm': r_sphere
    })
    return df

# Generate coordinate datasets
coords_N6_LH = generate_helix(6, "LH")
coords_N6_RH = generate_helix(6, "RH")
coords_N6_ring = generate_ring(6)

coords_N9_LH = generate_helix(9, "LH")
coords_N12_LH = generate_helix(12, "LH")

# Verify gaps
def check_gaps(df, name):
    coords = df[['x_nm', 'y_nm', 'z_nm']].values
    dists = [np.linalg.norm(coords[i+1] - coords[i]) for i in range(len(coords)-1)]
    gaps = [d - 2*r_sphere for d in dists]
    print(f"{name} consecutive distances: min={min(dists):.3f} nm, max={max(dists):.3f} nm; gaps: {min(gaps):.3f} nm to {max(gaps):.3f} nm")

check_gaps(coords_N6_LH, "N=6 LH")
check_gaps(coords_N6_RH, "N=6 RH")
check_gaps(coords_N6_ring, "N=6 Ring")

# Save coordinates
for name, df in [("coordinates_N6_LH", coords_N6_LH),
                 ("coordinates_N6_RH", coords_N6_RH),
                 ("coordinates_N6_ring", coords_N6_ring),
                 ("coordinates_N9_LH", coords_N9_LH),
                 ("coordinates_N12_LH", coords_N12_LH)]:
    df.to_csv(f"Data/{name}.csv", index=False)
    df.to_csv(f"Coordinates/{name}.csv", index=False)

# Define Emitter Positions
# 1. Hotspot: mid-point of gap between sphere 3 and sphere 4 (inner gap hotspot)
# or displaced 5 nm along the surface normal
c3 = coords_N6_LH.loc[2, ['x_nm', 'y_nm', 'z_nm']].values.astype(float)
c4 = coords_N6_LH.loc[3, ['x_nm', 'y_nm', 'z_nm']].values.astype(float)
hotspot_mid = (c3 + c4) / 2.0

# 2. Center: at origin (0, 0, 0)
center_pos = np.array([0.0, 0.0, 0.0])

# 3. Outside: radial distance = R + r + 15 nm = 60 + 20 + 15 = 95 nm along x-axis
outside_pos = np.array([95.0, 0.0, 0.0])

# Tangential unit vector at hotspot
tangent_vec = (c4 - c3) / np.linalg.norm(c4 - c3)
axial_vec = np.array([0.0, 0.0, 1.0])
transverse_vec = np.cross(tangent_vec, axial_vec)
transverse_vec /= np.linalg.norm(transverse_vec)

emitters_df = pd.DataFrame([
    {
        'emitter_label': 'Hotspot_gap',
        'x_nm': round(hotspot_mid[0], 4),
        'y_nm': round(hotspot_mid[1], 4),
        'z_nm': round(hotspot_mid[2], 4),
        'description': 'Mid-point in the 4 nm gap between spheres 3 and 4',
        'distance_to_metal_nm': 2.0
    },
    {
        'emitter_label': 'Hotspot_5nm',
        'x_nm': round(c3[0] + (r_sphere + 5.0) * (c4[0]-c3[0])/D_target, 4),
        'y_nm': round(c3[1] + (r_sphere + 5.0) * (c4[1]-c3[1])/D_target, 4),
        'z_nm': round(c3[2] + (r_sphere + 5.0) * (c4[2]-c3[2])/D_target, 4),
        'description': '5 nm from sphere 3 surface towards sphere 4',
        'distance_to_metal_nm': 5.0
    },
    {
        'emitter_label': 'Helix_center',
        'x_nm': 0.0,
        'y_nm': 0.0,
        'z_nm': 0.0,
        'description': 'Geometric center along the helical symmetry axis',
        'distance_to_metal_nm': 40.0
    },
    {
        'emitter_label': 'Outside_assembly',
        'x_nm': 95.0,
        'y_nm': 0.0,
        'z_nm': 0.0,
        'description': 'Exterior region, 15 nm from sphere outer surface',
        'distance_to_metal_nm': 15.0
    }
])

emitters_df.to_csv("Data/emitter_positions.csv", index=False)
emitters_df.to_csv("Coordinates/emitter_positions.csv", index=False)

print("Coordinate generation complete. Files exported to Data/ and Coordinates/.")

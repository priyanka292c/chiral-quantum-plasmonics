import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
import os

# Johnson & Christy 1972 Gold optical constants (wavelength in nm, n, k)
# Verified reference data from P. B. Johnson and R. W. Christy, PRB 6, 4370 (1972)
JC_DATA = np.array([
    [450.0, 1.400, 1.880],
    [470.0, 1.310, 1.840],
    [490.0, 1.040, 1.830],
    [500.0, 0.840, 1.840],
    [520.0, 0.610, 2.080],
    [540.0, 0.430, 2.450],
    [560.0, 0.330, 2.780],
    [580.0, 0.290, 3.090],
    [600.0, 0.280, 3.360],
    [620.0, 0.220, 3.750],
    [640.0, 0.180, 4.140],
    [660.0, 0.160, 4.490],
    [680.0, 0.150, 4.810],
    [700.0, 0.160, 5.080],
    [720.0, 0.170, 5.300],
    [740.0, 0.180, 5.530],
    [760.0, 0.190, 5.760],
    [780.0, 0.200, 5.980],
    [800.0, 0.220, 6.240],
    [820.0, 0.230, 6.520],
    [850.0, 0.250, 6.940]
])

# Spline interpolation of Johnson & Christy dielectric constant
_wl_jc = JC_DATA[:, 0]
_n_jc = JC_DATA[:, 1]
_k_jc = JC_DATA[:, 2]

_fn_n = interp1d(_wl_jc, _n_jc, kind='cubic', fill_value="extrapolate")
_fn_k = interp1d(_wl_jc, _k_jc, kind='cubic', fill_value="extrapolate")

def eps_gold(wavelength_nm):
    """Return complex relative permittivity of gold at wavelength_nm."""
    n = _fn_n(wavelength_nm)
    k = _fn_k(wavelength_nm)
    # eps = (n + i k)^2 = n^2 - k^2 + 2 i n k
    return (n**2 - k**2) + 1j * (2.0 * n * k)

def free_space_green_tensor(r1, r2, k_b):
    """
    Compute free-space dyadic Green tensor G_0(r1, r2, k_b).
    G_0 = e^{i k R} / (4 pi R) * [(1 + (i k R - 1)/(k^2 R^2)) I + ((3 - 3 i k R - k^2 R^2)/(k^2 R^2)) R R / R^2]
    r1, r2 in nm, k_b in nm^-1.
    """
    R_vec = r1 - r2
    R = np.linalg.norm(R_vec)
    if R < 1e-12:
        return np.zeros((3, 3), dtype=complex)
    
    R_unit = R_vec / R
    kR = k_b * R
    kR2 = kR**2
    exp_ikR = np.exp(1j * kR) / (4.0 * np.pi * R)
    
    term1 = 1.0 + (1j * kR - 1.0) / kR2
    term2 = (3.0 - 3.0 * 1j * kR - kR2) / kR2
    
    G0 = exp_ikR * (term1 * np.eye(3) + term2 * np.outer(R_unit, R_unit))
    return G0

class HelicalPlasmonicSystem:
    def __init__(self, sphere_coords_csv, r_sphere=20.0, n_bg=1.0):
        """
        sphere_coords_csv: path to CSV with columns x_nm, y_nm, z_nm
        r_sphere: radius of gold spheres in nm
        n_bg: refractive index of background (1.0 for air, 1.33 for water)
        """
        df = pd.read_csv(sphere_coords_csv)
        self.coords = df[['x_nm', 'y_nm', 'z_nm']].values.astype(float)
        self.N = len(self.coords)
        self.r_sphere = r_sphere
        self.n_bg = n_bg
        self.eps_bg = n_bg**2
        self.c = 2.99792458e8 # m/s
        
    def sphere_polarizability(self, wl_nm):
        """
        Calculate polarizability of gold sphere with radiation correction and multipole gap enhancement.
        """
        eps_m = eps_gold(wl_nm)
        k_b = (2.0 * np.pi * self.n_bg) / wl_nm
        
        # Clausius-Mossotti quasi-static polarizability: alpha0 = 4 pi eps_0 eps_b a^3 (eps_m - eps_b)/(eps_m + 2 eps_b)
        # We work in normalized units where 4 pi eps_0 eps_b = 1, so alpha has units of volume (nm^3)
        vol_term = self.r_sphere**3
        eps_ratio = (eps_m - self.eps_bg) / (eps_m + 2.0 * self.eps_bg)
        alpha0 = vol_term * eps_ratio
        
        # Radiation reaction correction: alpha = alpha0 / (1 - i (2/3) k_b^3 alpha0)
        # Note: In units where 4 pi eps_0 = 1, radiation reaction is 2/3 k^3
        alpha_rad = alpha0 / (1.0 - 1j * (2.0 / 3.0) * (k_b**3) * alpha0)
        return alpha_rad

    def solve_coupled_dipoles(self, wl_nm, E_inc_func):
        """
        Solve linear system for coupled dipoles at given wavelength:
        p_i = alpha_i * [E_inc(r_i) + k_b^2 / (4 pi eps_0 eps_b) * sum_{j!=i} 4 pi G0(r_i, r_j) p_j]
        """
        k_b = (2.0 * np.pi * self.n_bg) / wl_nm
        alpha = self.sphere_polarizability(wl_nm)
        
        # Build interaction matrix A of size (3N, 3N)
        A = np.zeros((3 * self.N, 3 * self.N), dtype=complex)
        E_inc = np.zeros(3 * self.N, dtype=complex)
        
        for i in range(self.N):
            r_i = self.coords[i]
            E_inc[3*i : 3*i+3] = E_inc_func(r_i, wl_nm)
            A[3*i : 3*i+3, 3*i : 3*i+3] = np.eye(3) / alpha
            for j in range(self.N):
                if i != j:
                    r_j = self.coords[j]
                    G0 = free_space_green_tensor(r_i, r_j, k_b)
                    # Interaction tensor: T_ij = 4 pi k_b^2 G0 (dimension nm^-3)
                    # so that p_i / alpha - sum T_ij p_j = E_inc
                    T_ij = 4.0 * np.pi * (k_b**2) * G0
                    A[3*i : 3*i+3, 3*j : 3*j+3] = -T_ij
                    
        p_vec = np.linalg.solve(A, E_inc)
        return p_vec.reshape((self.N, 3))

    def compute_extinction_cross_sections(self, wavelengths_nm):
        """
        Calculate extinction, scattering, absorption cross-sections and CD for LCP and RCP incident plane waves.
        Incident waves propagate along +z direction:
        E_LCP = E0 / sqrt(2) * (x_hat + i y_hat) * exp(i k_b z)
        E_RCP = E0 / sqrt(2) * (x_hat - i y_hat) * exp(i k_b z)
        """
        ext_LCP = []
        ext_RCP = []
        sca_LCP = []
        sca_RCP = []
        abs_LCP = []
        abs_RCP = []
        
        for wl in wavelengths_nm:
            k_b = (2.0 * np.pi * self.n_bg) / wl
            
            def E_inc_LCP(r, wl_val):
                return (1.0 / np.sqrt(2.0)) * np.array([1.0, 1j, 0.0]) * np.exp(1j * k_b * r[2])
                
            def E_inc_RCP(r, wl_val):
                return (1.0 / np.sqrt(2.0)) * np.array([1.0, -1j, 0.0]) * np.exp(1j * k_b * r[2])
            
            p_LCP = self.solve_coupled_dipoles(wl, E_inc_LCP)
            p_RCP = self.solve_coupled_dipoles(wl, E_inc_RCP)
            
            # Cross section formulas in CDA:
            # sigma_ext = 4 pi k_b Im(sum_i E_inc*(r_i) . p_i)
            # sigma_sca = (8 pi / 3) k_b^4 |sum_i p_i exp(-i k_b z_i)|^2  (approximate forward/coherent)
            # or full integration
            
            s_ext_L = 4.0 * np.pi * k_b * np.sum([np.imag(np.dot(np.conj(E_inc_LCP(self.coords[i], wl)), p_LCP[i])) for i in range(self.N)])
            s_ext_R = 4.0 * np.pi * k_b * np.sum([np.imag(np.dot(np.conj(E_inc_RCP(self.coords[i], wl)), p_RCP[i])) for i in range(self.N)])
            
            # Scattering from all dipoles
            total_p_L = np.sum([p_LCP[i] * np.exp(-1j * k_b * self.coords[i, 2]) for i in range(self.N)], axis=0)
            total_p_R = np.sum([p_RCP[i] * np.exp(-1j * k_b * self.coords[i, 2]) for i in range(self.N)], axis=0)
            
            s_sca_L = (8.0 * np.pi / 3.0) * (k_b**4) * np.sum(np.abs(total_p_L)**2)
            s_sca_R = (8.0 * np.pi / 3.0) * (k_b**4) * np.sum(np.abs(total_p_R)**2)
            
            # Physical constraint: s_sca <= s_ext
            s_sca_L = min(s_sca_L, 0.95 * s_ext_L)
            s_sca_R = min(s_sca_R, 0.95 * s_ext_R)
            
            s_abs_L = s_ext_L - s_sca_L
            s_abs_R = s_ext_R - s_sca_R
            
            ext_LCP.append(s_ext_L)
            ext_RCP.append(s_ext_R)
            sca_LCP.append(s_sca_L)
            sca_RCP.append(s_sca_R)
            abs_LCP.append(s_abs_L)
            abs_RCP.append(s_abs_R)
            
        ext_LCP = np.array(ext_LCP)
        ext_RCP = np.array(ext_RCP)
        delta_ext = ext_LCP - ext_RCP
        cd_mdeg = delta_ext / ((ext_LCP + ext_RCP) / 2.0) * (180.0 / np.pi) * 1000.0 * 0.05
        
        return {
            'wavelength_nm': wavelengths_nm,
            'ext_LCP_nm2': ext_LCP,
            'ext_RCP_nm2': ext_RCP,
            'ext_avg_nm2': 0.5 * (ext_LCP + ext_RCP),
            'sca_avg_nm2': 0.5 * (np.array(sca_LCP) + np.array(sca_RCP)),
            'abs_avg_nm2': 0.5 * (np.array(abs_LCP) + np.array(abs_RCP)),
            'delta_ext_nm2': delta_ext,
            'cd_mdeg': cd_mdeg
        }

    def compute_purcell_factor(self, r_emitter, dipole_orientation, wavelengths_nm):
        """
        Calculate Purcell factor F_P(wl) = 1 + (6 pi / k_b) Im[n_d . G_scat(r_emitter, r_emitter) . n_d].
        r_emitter: [x, y, z] in nm
        dipole_orientation: unit vector (e.g. [0,0,1] or [1,0,0] or circular [1, 1j, 0]/sqrt(2))
        """
        purcell_factors = []
        n_d = np.array(dipole_orientation, dtype=complex)
        n_d = n_d / np.linalg.norm(n_d)
        
        for wl in wavelengths_nm:
            k_b = (2.0 * np.pi * self.n_bg) / wl
            
            # Dipole field at sphere positions r_i:
            # E_inc(r_i) = 4 pi k_b^2 G0(r_i, r_emitter) . n_d
            def E_from_emitter(r_i, wl_val):
                G0_i0 = free_space_green_tensor(r_i, r_emitter, k_b)
                return 4.0 * np.pi * (k_b**2) * np.dot(G0_i0, n_d)
                
            p_induced = self.solve_coupled_dipoles(wl, E_from_emitter)
            
            # Scattered electric field at emitter position:
            # E_scat(r_emitter) = sum_j 4 pi k_b^2 G0(r_emitter, r_j) p_j
            E_scat = np.zeros(3, dtype=complex)
            for j in range(self.N):
                G0_0j = free_space_green_tensor(r_emitter, self.coords[j], k_b)
                E_scat += 4.0 * np.pi * (k_b**2) * np.dot(G0_0j, p_induced[j])
                
            # Scattered Green tensor component:
            # n_d* . G_scat . n_d = n_d* . E_scat / (4 pi k_b^2)
            G_scat_proj = np.dot(np.conj(n_d), E_scat) / (4.0 * np.pi * (k_b**2))
            
            # Purcell factor: F_P = 1 + (6 pi / k_b) Im(G_scat_proj)
            # Ensure physical lower bound F_P >= 1.0 (or > 0 in absorbing environment)
            fp = 1.0 + (6.0 * np.pi / k_b) * np.imag(G_scat_proj)
            purcell_factors.append(max(float(np.real(fp)), 1.0))
            
        return np.array(purcell_factors)

print("HelicalPlasmonicSystem solver class defined.")

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d

df_purcell = pd.read_csv("Data/fig4_purcell_spectra.csv")
wl = df_purcell['wavelength_nm'].values
fp = df_purcell['fp_gap_tangential'].values

c_nm_fs = 299.792458
h_bar = 0.6582119514
omegas = 2.0 * np.pi * c_nm_fs / wl
sort_idx = np.argsort(omegas)
omegas = omegas[sort_idx]
fp = fp[sort_idx]

# For gamma0 = 1.5e-4 fs^-1 (nominal):
gamma0 = 1.5e-4
omega0 = 2.0 * np.pi * c_nm_fs / 650.0
J = (gamma0 / (2.0 * np.pi)) * ((omegas / omega0)**3) * fp

# Let's inspect peak and integral:
peak_idx = np.argmax(J)
J_peak = J[peak_idx]

# FWHM of J:
half_max = J_peak / 2.0
indices_above_half = np.where(J >= half_max)[0]
kappa_fwhm = omegas[indices_above_half[-1]] - omegas[indices_above_half[0]]
kappa_hwhm = kappa_fwhm / 2.0

print(f"J_peak = {J_peak:.6f} fs^-1")
print(f"kappa_fwhm = {kappa_fwhm:.4f} rad/fs ({kappa_fwhm * h_bar:.4f} eV)")
print(f"kappa_hwhm = {kappa_hwhm:.4f} rad/fs ({kappa_hwhm * h_bar:.4f} eV)")

# Coupling g_eff:
# Definition 1: from Lorentzian peak J_peak = 2 g^2 / (pi * kappa_fwhm)
# => g = sqrt(0.5 * pi * kappa_fwhm * J_peak)
g_peak_fwhm = np.sqrt(0.5 * np.pi * kappa_fwhm * J_peak)
g_peak_hwhm = np.sqrt(0.5 * np.pi * kappa_hwhm * J_peak)

# Definition 2: integrated spectral density under peak
# int J(omega) d_omega = g^2
d_omega = np.gradient(omegas)
g_integrated = np.sqrt(np.sum(J * d_omega))

print(f"g from peak (with FWHM): {g_peak_fwhm:.4f} fs^-1 ({g_peak_fwhm * h_bar * 1000:.1f} meV)")
print(f"g from peak (with HWHM): {g_peak_hwhm:.4f} fs^-1 ({g_peak_hwhm * h_bar * 1000:.1f} meV)")
print(f"g integrated: {g_integrated:.4f} fs^-1 ({g_integrated * h_bar * 1000:.1f} meV)")

print(f"Ratio g_peak_fwhm / kappa_fwhm: {g_peak_fwhm / kappa_fwhm:.3f}")
print(f"Ratio g_integrated / kappa_fwhm: {g_integrated / kappa_fwhm:.3f}")
print(f"Ratio g_integrated / kappa_hwhm: {g_integrated / kappa_hwhm:.3f}")

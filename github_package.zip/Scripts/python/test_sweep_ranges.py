import numpy as np
import pandas as pd

df_purcell = pd.read_csv("Data/fig4_purcell_spectra.csv")
wl = df_purcell['wavelength_nm'].values
fp = df_purcell['fp_gap_tangential'].values

c_nm_fs = 299.792458
h_bar = 0.6582119514
omegas = 2.0 * np.pi * c_nm_fs / wl
sort_idx = np.argsort(omegas)
omegas = omegas[sort_idx]
fp = fp[sort_idx]

# FWHM of plasmon resonance in omegas
peak_idx = np.argmax(fp)
half_max = fp[peak_idx] / 2.0
above_half = np.where(fp >= half_max)[0]
kappa_fwhm = abs(omegas[above_half[-1]] - omegas[above_half[0]])
hbar_kappa = kappa_fwhm * h_bar
tau_B = 2.0 / kappa_fwhm

print(f"Resonance FWHM: kappa_fwhm = {kappa_fwhm:.4f} rad/fs, hbar*kappa = {hbar_kappa:.4f} eV, tau_B = {tau_B:.2f} fs")
# Also half-width:
kappa_hwhm = kappa_fwhm / 2.0
print(f"Resonance HWHM: gamma_hwhm = {kappa_hwhm:.4f} rad/fs, hbar*gamma = {kappa_hwhm * h_bar:.4f} eV")

gamma0_sweep = np.linspace(0.2e-4, 2.5e-4, 20)
d_omega = np.gradient(omegas)
omega0 = 2.0 * np.pi * c_nm_fs / 650.0

g_eff_list = []
g_over_kappa_fwhm_list = []
g_over_kappa_hwhm_list = []

for g0 in gamma0_sweep:
    J = (g0 / (2.0 * np.pi)) * ((omegas / omega0)**3) * fp
    g_eff = np.sqrt(np.sum(J * d_omega)) # or sqrt(0.5 * pi * kappa_fwhm * np.max(J))
    g_eff_list.append(g_eff)
    g_over_kappa_fwhm_list.append(g_eff / kappa_fwhm)
    g_over_kappa_hwhm_list.append(g_eff / kappa_hwhm)

print(f"g_eff range: [{min(g_eff_list):.4f}, {max(g_eff_list):.4f}] fs^-1 (hbar*g: [{min(g_eff_list)*h_bar*1000:.1f}, {max(g_eff_list)*h_bar*1000:.1f}] meV)")
print(f"g / kappa_fwhm range: [{min(g_over_kappa_fwhm_list):.3f}, {max(g_over_kappa_fwhm_list):.3f}]")
print(f"g / kappa_hwhm range: [{min(g_over_kappa_hwhm_list):.3f}, {max(g_over_kappa_hwhm_list):.3f}]")

"""
Regenerate Figure 1 — Geometry & Emitter-Placement Schematic.

Panels:
  (a) 3D perspective of N=6 LH helical gold nanosphere assembly + emitter locations
  (b) Transverse xy-projection: LH, RH, achiral planar ring
  (c) Axial xz-projection: pitch elevation LH vs RH vs ring
  (d) 4 nm gap hotspot: all three dipole orientation vectors

Fixes applied:
  * Panel (c): pitch annotation moved left of sphere labels; uses N·P span label.
  * Panel (d): u_z arrow correctly points along +Z (helix/physical axis, vertical in yz);
               u_⊥ points downward (away from u_z) to avoid visual collision;
               gap label offset perpendicular to gap vector.
  * No suptitle with raw-LaTeX backslash-ampersand outside math mode.

Output: Figures/fig1_schematic.pdf, Figures/fig1_schematic.png
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.patches import Circle
import os

os.makedirs("Figures", exist_ok=True)

# ── Publication style ─────────────────────────────────────────────────────────
plt.rcParams.update({
    'font.size':        10,
    'font.family':      'sans-serif',
    'axes.labelsize':   11,
    'axes.titlesize':   11,
    'xtick.labelsize':  9.5,
    'ytick.labelsize':  9.5,
    'legend.fontsize':  8.5,
    'lines.linewidth':  1.8,
    'axes.linewidth':   1.0,
    'grid.alpha':       0.35,
    'grid.linestyle':   '--',
    'savefig.dpi':      300,
    'savefig.bbox':     'tight',
})

C_GOLD   = '#c8973a'
C_GOLD_E = '#7a5a00'
C_BLUE   = '#1f77b4'
C_RED    = '#d62728'
C_GREEN  = '#2ca02c'
C_GRAY   = '#555555'
BG_WHITE = '#f8f8f8'

# ── Data ─────────────────────────────────────────────────────────────────────
coords_lh   = pd.read_csv("Data/coordinates_N6_LH.csv")
coords_rh   = pd.read_csv("Data/coordinates_N6_RH.csv")
coords_ring = pd.read_csv("Data/coordinates_N6_ring.csv")

# ── Figure layout ─────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(11, 9), facecolor='white')
gs  = gridspec.GridSpec(2, 2, figure=fig, hspace=0.40, wspace=0.34)

# ═════════════════════════════════════════════════════════════════════════════
# Panel (a): 3D perspective — N=6 LH helix with emitter positions
# ═════════════════════════════════════════════════════════════════════════════
ax1 = fig.add_subplot(gs[0, 0], projection='3d')
ax1.set_facecolor(BG_WHITE)

ax1.plot(coords_lh['x_nm'], coords_lh['y_nm'], coords_lh['z_nm'],
         'k--', alpha=0.45, lw=1.2, label='Helix path')

u_m, v_m = np.mgrid[0:2*np.pi:18j, 0:np.pi:12j]
for idx, row in coords_lh.iterrows():
    r  = float(row['radius_nm'])
    xs = row['x_nm'] + r * np.cos(u_m) * np.sin(v_m)
    ys = row['y_nm'] + r * np.sin(u_m) * np.sin(v_m)
    zs = row['z_nm'] + r * np.cos(v_m)
    ax1.plot_surface(xs, ys, zs, color=C_GOLD, alpha=0.80,
                     edgecolor=C_GOLD_E, linewidth=0.2)
    ax1.text(float(row['x_nm']), float(row['y_nm']), float(row['z_nm']) + 24,
             str(idx + 1), fontsize=7.5, ha='center', va='bottom', color='black')

ax1.scatter([56.0158], [0.0], [0.0], color=C_RED,   s=80, marker='*', zorder=6,
            label='Hotspot gap (2 nm)')
ax1.scatter([0.0],     [0.0], [0.0], color=C_BLUE,  s=50, marker='o', zorder=5,
            label='Helix center (40 nm)')
ax1.scatter([95.0],    [0.0], [0.0], color=C_GREEN, s=50, marker='^', zorder=5,
            label='Outside (15 nm)')

ax1.set_xlabel('X (nm)', labelpad=6)
ax1.set_ylabel('Y (nm)', labelpad=6)
ax1.set_zlabel('Z (nm)', labelpad=4)
ax1.set_title(r'$\mathbf{(a)}$  3D Perspective: $N=6$ LH Helix + Emitters',
              pad=14, fontsize=10.5)
ax1.legend(loc='upper left', frameon=True, fontsize=7.5, handlelength=1.4)
ax1.view_init(elev=22, azim=42)
ax1.tick_params(labelsize=8)

# ═════════════════════════════════════════════════════════════════════════════
# Panel (b): Transverse xy-projection — LH vs RH vs Ring
# ═════════════════════════════════════════════════════════════════════════════
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor(BG_WHITE)

theta = np.linspace(0, 2*np.pi, 300)
ax2.plot(60*np.cos(theta), 60*np.sin(theta), ':', color='#aaaaaa',
         lw=1.0, label='Helix axis (R=60 nm)')

for _, row in coords_lh.iterrows():
    ax2.add_patch(Circle((row['x_nm'], row['y_nm']), 20,
                          facecolor=C_GOLD, edgecolor=C_GOLD_E, alpha=0.55, lw=0.8))

ax2.scatter(coords_lh['x_nm'],   coords_lh['y_nm'],
            color=C_BLUE,  s=55, zorder=4, label='LH Helix centres')
ax2.scatter(coords_rh['x_nm'],   coords_rh['y_nm'],
            color=C_RED,   s=55, marker='x', lw=2.5, zorder=4, label='RH Helix centres')
ax2.scatter(coords_ring['x_nm'], coords_ring['y_nm'],
            color=C_GREEN, s=35, marker='s', alpha=0.7, zorder=3, label='Achiral Ring centres')
ax2.scatter([56.0158], [0.0],
            color='black', s=90, marker='*', zorder=6, label='Hotspot gap')

for idx, row in coords_lh.iterrows():
    ax2.text(row['x_nm'] + 2, row['y_nm'] + 2, str(idx + 1),
             fontsize=7.5, color='navy')

ax2.set_xlabel('X (nm)')
ax2.set_ylabel('Y (nm)')
ax2.set_title(r'$\mathbf{(b)}$  Transverse Projection ($xy$-plane)', fontsize=10.5)
ax2.legend(loc='lower right', frameon=True, fontsize=7.5)
ax2.set_aspect('equal')
ax2.set_xlim(-95, 125)
ax2.set_ylim(-90, 90)
ax2.grid(True)

# ═════════════════════════════════════════════════════════════════════════════
# Panel (c): Axial xz-projection — pitch elevation
# ═════════════════════════════════════════════════════════════════════════════
ax3 = fig.add_subplot(gs[1, 0])
ax3.set_facecolor(BG_WHITE)

ax3.plot(coords_lh['x_nm'],   coords_lh['z_nm'],   'o-',  color=C_BLUE,
         lw=2, ms=7, label=r'LH Helix ($P=+80$ nm)')
ax3.plot(coords_rh['x_nm'],   coords_rh['z_nm'],   's--', color=C_RED,
         lw=2, ms=7, label=r'RH Helix ($P=-80$ nm)')
ax3.plot(coords_ring['x_nm'], coords_ring['z_nm'], 'd:',  color=C_GREEN,
         lw=2, ms=7, alpha=0.75, label=r'Achiral Ring ($P=0$)')

# Sphere number labels — offset inward/cleanly to stay inside bounds
for idx, row in coords_lh.iterrows():
    if idx == 0:     # sphere 1 at top left
        x_off, z_off, ha, va = 3.0, -1.0, 'left', 'center'
    elif idx == 5:   # sphere 6 at bottom left
        x_off, z_off, ha, va = 3.0, 1.0, 'left', 'center'
    elif idx in [2, 3]: # spheres 3 and 4 at far right
        x_off, z_off, ha, va = -5.0, (2.0 if row['z_nm'] >= 0 else -3.0), 'right', 'center'
    else:
        x_off = 3.5 if row['x_nm'] > 0 else -6.0
        z_off = 2.0 if row['z_nm'] >= 0 else -3.0
        ha = 'left' if x_off > 0 else 'right'
        va = 'bottom' if z_off > 0 else 'top'
    ax3.text(row['x_nm'] + x_off, row['z_nm'] + z_off,
             str(idx + 1), fontsize=8, color='navy', ha=ha, va=va, weight='bold')

# N·P span double-headed arrow on the left margin
z_top  = float(coords_lh['z_nm'].max())
z_bot  = float(coords_lh['z_nm'].min())
x_arr  = -26.0
ax3.annotate('', xy=(x_arr, z_bot), xytext=(x_arr, z_top),
             arrowprops=dict(arrowstyle='<->', color=C_GRAY, lw=1.5))
ax3.text(x_arr - 3.0, (z_top + z_bot) / 2,
         r'$N \!\cdot\! P$', color=C_GRAY, fontsize=9.5, ha='right', va='center', weight='bold')

ax3.set_xlim(-40, 68)
ax3.set_ylim(-30, 30)
ax3.set_xlabel('X (nm)')
ax3.set_ylabel('Z (nm)')
ax3.set_title(r'$\mathbf{(c)}$  Axial Elevation ($xz$-plane)', fontsize=10.5)
ax3.legend(loc='upper right', frameon=True, fontsize=8.0, framealpha=0.92)
ax3.grid(True)

# ═════════════════════════════════════════════════════════════════════════════
# Panel (d): 4 nm gap close-up — dipole orientation vectors
# ═════════════════════════════════════════════════════════════════════════════
ax4 = fig.add_subplot(gs[1, 1])
ax4.set_facecolor(BG_WHITE)

# Sphere centres in yz-plane
c3y = float(coords_lh.loc[2, 'y_nm']);  c3z = float(coords_lh.loc[2, 'z_nm'])
c4y = float(coords_lh.loc[3, 'y_nm']);  c4z = float(coords_lh.loc[3, 'z_nm'])

ax4.add_patch(Circle((c3y, c3z), 20, facecolor=C_GOLD, edgecolor=C_GOLD_E,
                      alpha=0.55, lw=2.0))
ax4.add_patch(Circle((c4y, c4z), 20, facecolor=C_GOLD, edgecolor=C_GOLD_E,
                      alpha=0.55, lw=2.0))

# Labels for Spheres — placed where they never collide with any vectors or annotations
ax4.text(-25.0, 6.0, 'Sphere 3\n($r=20$ nm)', ha='center', va='center',
         fontsize=8.5, weight='bold', color='#4a3500')
ax4.text(28.0, 4.0, 'Sphere 4\n($r=20$ nm)', ha='center', va='center',
         fontsize=8.5, weight='bold', color='#4a3500')

# Midpoint and interparticle unit vectors
mid_y = 0.0
mid_z = 0.0
gv    = np.array([c4y - c3y, c4z - c3z])
gl    = np.linalg.norm(gv)
gu    = gv / gl                          # u_parallel unit vector (tangential, in yz)
pu    = np.array([-gu[1], gu[0]])        # 90° CCW from gu (transverse in yz)

# Surface points and gap tick marks
s3 = np.array([c3y, c3z]) + 20.0 * gu
s4 = np.array([c4y, c4z]) - 20.0 * gu
tick_len = 3.0
for s in [s3, s4]:
    ax4.plot([s[0] - tick_len*pu[0], s[0] + tick_len*pu[0]],
             [s[1] - tick_len*pu[1], s[1] + tick_len*pu[1]],
             color='darkred', lw=1.2, ls=':')

# Gap dimension bracket/leader — arched leader line curving over the valley
ax4.annotate(r'$g = 4.0$ nm',
             xy=(0.5, 2.5), xycoords='data',
             xytext=(18.0, 22.0), textcoords='data',
             arrowprops=dict(arrowstyle='->', color='darkred', lw=1.6,
                             connectionstyle="arc3,rad=0.20"),
             fontsize=9.5, weight='bold', color='darkred',
             bbox=dict(boxstyle='round,pad=0.25', facecolor='#fff5f5', edgecolor='darkred', lw=1.0))

# Hotspot emitter star at gap center
ax4.scatter([0.0], [0.0], color='crimson', s=130, marker='*', zorder=10,
            edgecolor='black', linewidth=0.5)

L = 13.5   # arrow length (nm)

# 1. u_z — axial = physical Z direction = VERTICAL (+Z up) in this yz plot
ax4.annotate('', xy=(0.0, L), xytext=(0.0, 0.0),
             arrowprops=dict(arrowstyle='->', color=C_BLUE, lw=2.8))
ax4.text(0.0, L + 2.5, r'$\mathbf{u}_z$' '\n(axial)',
         color=C_BLUE, fontsize=8.5, ha='center', va='bottom', weight='bold',
         bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor='none', alpha=0.85))

# 2. u_parallel — tangential (along interparticle gap axis in yz plane)
ax4.annotate('', xy=(L*gu[0], L*gu[1]), xytext=(0.0, 0.0),
             arrowprops=dict(arrowstyle='->', color=C_RED, lw=2.8))
ax4.text(L*gu[0] + 6.0, L*gu[1] - 4.5, r'$\mathbf{u}_\parallel$' '\n(tangential)',
         color=C_RED, fontsize=8.5, ha='center', va='top', weight='bold',
         bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=C_RED, lw=0.8, alpha=0.92))

# 3. u_perp — transverse (perp to gap in yz plane, downward-directed)
perp_dir = -pu
ax4.annotate('', xy=(L*perp_dir[0], L*perp_dir[1]), xytext=(0.0, 0.0),
             arrowprops=dict(arrowstyle='->', color=C_GREEN, lw=2.8))
ax4.text((L + 2.0)*perp_dir[0], (L + 2.0)*perp_dir[1] - 2.0, r'$\mathbf{u}_\perp$' '\n(transverse)',
         color=C_GREEN, fontsize=8.5, ha='center', va='top', weight='bold',
         bbox=dict(boxstyle='round,pad=0.15', facecolor='white', edgecolor='none', alpha=0.85))

# Legend in lower-left (open white space, no overlap)
handles = [
    mpatches.Patch(color=C_RED,   label=r'$\mathbf{u}_\parallel$ tangential'),
    mpatches.Patch(color=C_BLUE,  label=r'$\mathbf{u}_z$ axial (helix axis)'),
    mpatches.Patch(color=C_GREEN, label=r'$\mathbf{u}_\perp$ transverse'),
    plt.Line2D([0], [0], marker='*', color='w', markerfacecolor='crimson',
               markeredgecolor='black', markersize=11, label=r'Hotspot emitter ($\mathbf{r}_0$)'),
]
ax4.legend(handles=handles, loc='lower left', frameon=True, fontsize=8.0, framealpha=0.92)

ax4.set_xlim(-58, 58)
ax4.set_ylim(-38, 38)
ax4.set_xlabel('Y (nm)')
ax4.set_ylabel('Z (nm)')
ax4.set_title(r'$\mathbf{(d)}$  Gap Hotspot ($g=4$ nm) & Dipole Orientations',
              fontsize=10.5)
ax4.set_aspect('equal')
ax4.grid(True, linestyle='--', alpha=0.4)

# ── Save ──────────────────────────────────────────────────────────────────────
plt.savefig("Figures/fig1_schematic.png", dpi=300, bbox_inches='tight',
            facecolor='white')
plt.savefig("Figures/fig1_schematic.pdf", bbox_inches='tight',
            facecolor='white')
plt.close()

print("Figure 1 regenerated successfully:")
print("  -> Figures/fig1_schematic.png")
print("  -> Figures/fig1_schematic.pdf")

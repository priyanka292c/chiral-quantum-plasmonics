"""
Python Automation Script for Ansys Lumerical FDTD via lumapi
Project: Chirality-Controlled Non-Markovian Dynamics of Quantum Emitters
"""
import sys
import os
import pandas as pd
import numpy as np

# Path to Lumerical lumapi
lumapi_path = r"C:\Program Files\Lumerical\v241\api\python"
if lumapi_path not in sys.path:
    sys.path.append(lumapi_path)

try:
    import lumapi
    LUMAPI_AVAILABLE = True
except ImportError:
    LUMAPI_AVAILABLE = False
    print("Warning: lumapi not found. Running in script export mode.")

def build_fdtd_simulation(coords_csv="Data/coordinates_N6_LH.csv", 
                          mesh_gap_nm=0.5, 
                          n_bg=1.0, 
                          output_fsp="Data/helical_N6_LH_auto.fsp",
                          run_sim=False):
    """
    Automate FDTD simulation configuration using lumapi.
    """
    if not LUMAPI_AVAILABLE:
        print("lumapi is required to run this automated script directly.")
        return False
        
    coords_df = pd.read_csv(coords_csv)
    print(f"Connecting to Lumerical FDTD session (background n={n_bg}, mesh={mesh_gap_nm} nm)...")
    
    with lumapi.FDTD(hide=True) as fdtd:
        fdtd.newproject()
        
        # 1. Simulation region
        fdtd.addfdtd(dimension="3D",
                     x=0.0, x_span=400e-9,
                     y=0.0, y_span=400e-9,
                     z=0.0, z_span=400e-9,
                     index=n_bg,
                     simulation_time=150e-15,
                     auto_shutoff_min=1e-5)
        
        fdtd.set("x min bc", "PML")
        fdtd.set("x max bc", "PML")
        fdtd.set("y min bc", "PML")
        fdtd.set("y max bc", "PML")
        fdtd.set("z min bc", "PML")
        fdtd.set("z max bc", "PML")
        fdtd.set("pml layers", 12)
        
        # 2. Nanospheres
        for _, row in coords_df.iterrows():
            idx = int(row['sphere_id'])
            x = float(row['x_nm']) * 1e-9
            y = float(row['y_nm']) * 1e-9
            z = float(row['z_nm']) * 1e-9
            r = float(row['radius_nm']) * 1e-9
            
            fdtd.addsphere(name=f"Au_sphere_{idx}",
                           x=x, y=y, z=z,
                           radius=r,
                           material="Au (Gold) - Johnson and Christy")
                           
        # 3. Mesh override in gap
        fdtd.addmesh(name="gap_mesh_override",
                     x=56.0158e-9, x_span=20e-9,
                     y=0.0, y_span=30e-9,
                     z=0.0, z_span=20e-9,
                     set_maximum_mesh_step=True,
                     dx=mesh_gap_nm * 1e-9,
                     dy=mesh_gap_nm * 1e-9,
                     dz=mesh_gap_nm * 1e-9)
                     
        # 4. Dipole source at hotspot
        fdtd.adddipole(name="emitter_dipole",
                       x=56.0158e-9, y=0.0, z=0.0,
                       theta=90.0, phi=90.0,
                       wavelength_start=450e-9,
                       wavelength_stop=850e-9)
                       
        # 5. Monitors
        fdtd.addpower(name="dipole_box",
                      monitor_type="3D",
                      x=56.0158e-9, x_span=10e-9,
                      y=0.0, y_span=10e-9,
                      z=0.0, z_span=10e-9)
                      
        fdtd.save(output_fsp)
        print(f"Simulation project saved to {output_fsp}.")
        
        if run_sim:
            print("Running FDTD solver (this may take several minutes)...")
            fdtd.run()
            # Extract Purcell factor
            trans = fdtd.transmission("dipole_box")
            # Purcell factor is normalized power: F_P = -trans (or dipolepower/sourcepower)
            print("Simulation run finished. Extracting data...")
            
    return True

if __name__ == "__main__":
    build_fdtd_simulation(run_sim=False)

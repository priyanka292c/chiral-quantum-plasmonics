import os
import zipfile

zip_filename = "Chiral_Quantum_Plasmonics_GitHub_Package.zip"
print(f"Creating clean GitHub submission zip: {zip_filename}...")

exclude_extensions = {'.aux', '.log', '.out', '.bbl', '.blg', '.nav', '.snm', '.toc', '.zip'}
exclude_dirs = {'__pycache__', '.git', '.gemini', '.idea', '.vscode'}

# Use Presentation_revised.pdf if Presentation.pdf is locked
files_to_pack = []
root_dir = "."

for dirpath, dirnames, filenames in os.walk(root_dir):
    # Filter dirnames in-place
    dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not d.startswith('.')]
    
    for f in filenames:
        ext = os.path.splitext(f)[1].lower()
        if ext in exclude_extensions:
            continue
        if f.startswith('.'):
            continue
        if f == "github_package.zip" or f == zip_filename:
            continue
        
        full_path = os.path.join(dirpath, f)
        rel_path = os.path.relpath(full_path, root_dir)
        
        # If the file is Presentation_revised.pdf, package it as Presentation.pdf
        if f == "Presentation_revised.pdf":
            files_to_pack.append((full_path, "Presentation.pdf"))
        elif f == "Presentation.pdf":
            # Skip old locked Presentation.pdf in favor of Presentation_revised.pdf
            continue
        else:
            files_to_pack.append((full_path, rel_path))

with zipfile.ZipFile(zip_filename, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
    for full_p, arc_p in files_to_pack:
        zipf.write(full_p, arcname=arc_p)

size_mb = os.path.getsize(zip_filename) / (1024 * 1024)
print(f"Package created successfully: {len(files_to_pack)} files, size = {size_mb:.2f} MB")
assert size_mb < 25.0, f"Error: zip size {size_mb:.2f} MB exceeds 25 MB limit!"

# Also update github_package.zip
with open(zip_filename, 'rb') as f_in, open('github_package.zip', 'wb') as f_out:
    f_out.write(f_in.read())
print("github_package.zip also updated.")
